export class ServicesList {
    constructor(public name: string) {}
}