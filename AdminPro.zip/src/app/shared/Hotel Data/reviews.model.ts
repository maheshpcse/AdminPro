export class ReviewList {
    constructor(
        public name: string, 
        public review: string, 
        public rating: number
    ) {}
}