export class RoomsList {
    constructor(
        public Type: string,
        public Desc: string,
        public AvalRooms: number,
        public Cost: number
    ) {}
}