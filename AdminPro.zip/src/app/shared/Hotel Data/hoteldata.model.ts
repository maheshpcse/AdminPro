export class HotelData {
    constructor(
        // Hotel details
        public hotelImage: string,
        public hotelName: string,
        public hotelRating: number,
        public hotelDesc: string,
        public Currency: string,

        // Hotel Rooms List
        public hotelRooms: any[],
        
        public hotelAddr: string,
        public latitude: number,
        public longitude: number,

        // Hotel Services List
        public hotelServices: any[],

        // Hotel Reviews List
        public hotelReviews: any[]
    ) {}
}