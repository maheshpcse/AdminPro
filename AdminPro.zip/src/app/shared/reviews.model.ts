export class Reviews {
    constructor(
        public name: String,
        public email: String,
        public review: String,
        public rating: number
    ) {}
}