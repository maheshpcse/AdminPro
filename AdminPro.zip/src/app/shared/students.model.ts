export class Students {
    constructor(
        public firstname: String,
        public lastname: String,
        public username: String,
        public email: String,
        public password: any,
        public phonenumber: number,
        public image: String
    ) {}
}