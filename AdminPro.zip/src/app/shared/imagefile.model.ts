export class ImageFile{
    constructor(public hotelImg: string) {}
}