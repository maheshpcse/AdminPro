export class OptionsList {
    constructor(
        public image: string,
        public option: string,
        public text: any[],
        public review: any[]
    ) {}
}