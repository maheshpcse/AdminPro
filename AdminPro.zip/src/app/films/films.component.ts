import { Component, OnInit } from '@angular/core';
import { FilmsServicesService } from '../services/films-service/films-services.service';
import { ActivatedRoute, Router } from '@angular/router';
import * as $ from 'jquery';
import { CharServicesService } from '../services/char-service/char-services.service';

@Component({
  selector: 'app-films',
  templateUrl: './films.component.html',
  styleUrls: ['./films.component.css']
})
export class FilmsComponent implements OnInit {

  films: any;

  constructor(
    private flimsSrv: FilmsServicesService,
    private route: ActivatedRoute,
    private router: Router
  ) { }

  ngOnInit() {
    this.flimsList();
  }

  // Get All Films Data
  flimsList() {
    this.flimsSrv.getAllFilms().subscribe(
      (res) => {
        console.log(res);
        this.films = res;
      }, (err) => {
        console.log(err);
      }
    );
  }

}
