import { Component, OnInit } from '@angular/core';
import { FilmsServicesService } from 'src/app/services/films-service/films-services.service';
import { ActivatedRoute, Router } from '@angular/router';
import { CharServicesService } from 'src/app/services/char-service/char-services.service';
import * as $ from 'jquery';

@Component({
  selector: 'app-view-film',
  templateUrl: './view-film.component.html',
  styleUrls: ['./view-film.component.css']
})
export class ViewFilmComponent implements OnInit {

  private id: any;

  // Films Data
  film: Object = {
    title: '',
    episode_id: '',
    opening_crawl: '',
    director: '',
    producer: '',
    release_date: ''
  }

  // Characters Data
  actors: any;

  constructor(
    private filmsSrv: FilmsServicesService,
    private charSrv: CharServicesService,
    private route: ActivatedRoute,
    private router: Router
  ) { }

  ngOnInit() {
    this.getOneFilm();
    this.charactersList();
  }

  // Get One Film Data By Id
  getOneFilm() {
    console.log("Get One Film By Id");
    this.route.params.subscribe(
      (res) => {
        console.log(res);
        this.id = res.filmId;
        console.log(this.id);
      });
    this.filmsSrv.getOneFilmById(this.id).subscribe(
      (res) => {
        this.film = res;
        console.log('This is One Film Data By Id', res);
      }, (err) => {
        console.log(err);
      }
    );
  }

  // Get All Characters Data
  charactersList() {
    this.charSrv.getAllCharacters().subscribe(
      (res) => {
        console.log(res);
        this.actors = res;
      }, (err) => {
        console.log(err);
      }
    );
  }

}
