import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthServicesService } from 'src/app/services/auth-service/auth-services.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-header-nav',
  templateUrl: './header-nav.component.html',
  styleUrls: ['./header-nav.component.css']
})
export class HeaderNavComponent implements OnInit {

  userId: any;
  role: any;
  constructor(
    private authSrv: AuthServicesService,
    private route: Router
  ) { }

  ngOnInit() {
  }

  signedOut() {
    localStorage.removeItem('token');
    localStorage.removeItem('role');
    localStorage.removeItem('userId');
    localStorage.removeItem('username');
    localStorage.clear();
    console.clear();
    this.role = null;
    this.route.navigateByUrl("/home");
    const toast = Swal.mixin({
      toast: true,
      position: 'top-end',
      showConfirmButton: false,
      timer: 3000
    });
    toast.fire ({
      type: 'success',
      title: 'Signed out successfully'
    });
  }

  content = false;
  content1 = false;
  content2 = false;
  content3 = false;

  isClick() {
    this.content = true;
  }

  isClick1() {
    this.content1 = true;
  }

  isClick2() {
    this.content2 = true;
  }

  isClick3() {
    this.content3 = true;
  }
}