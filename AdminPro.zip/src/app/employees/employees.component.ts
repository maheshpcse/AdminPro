import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { EmployeeServicesService } from '../services/employee-service/employee-services.service';
import { ActivatedRoute } from '@angular/router';
import Swal from 'sweetalert2';
import { FileUploader, FileSelectDirective } from 'ng2-file-upload/ng2-file-upload';

@Component({
  selector: 'app-employees',
  templateUrl: './employees.component.html',
  styleUrls: ['./employees.component.css']
})
export class EmployeesComponent implements OnInit {

  employees: any;

  private empId: any;

  employeeData: any = {
    name: '',
    email: '',
    phoneNum: '',
    profileImg: ''
  }

  Image: any;
  formData = new FormData();
  @ViewChild("fileInput", {static: false}) fileInputRef: ElementRef;

  constructor(
    private empSrv: EmployeeServicesService,
    private route: ActivatedRoute
  ) { }

  ngOnInit() {
    this.getEmpData();
  }

  onFileSelected(event) {
    console.log(event.target.files[0]);
    this.formData.append('profileImg', event.target.files[0]);

    // var reader = new FileReader();
    // var file = event.target.files[0];
    // reader.readAsDataURL(file);
    // reader.onload = () => {
    //   this.Image = reader.result;
    // }
  }

  // Save Employee Data
  saveEmpData() {
    console.log(this.employeeData);

    this.formData.append('name', this.employeeData.name);
    this.formData.append('email', this.employeeData.email);
    this.formData.append('phoneNum', this.employeeData.phoneNum);
    this.empSrv.saveEmpData(this.formData).subscribe(
      (res) => {
        console.log(res);
        this.employeeData = res;
        this.formData.delete('name');
        this.formData.delete('email');
        this.formData.delete('phoneNum');
        this.formData.delete('profileImg');

        const toast = Swal.mixin({
          toast: true,
          position: 'center',
          showConfirmButton: false,
          timer: 3000
        });
        toast.fire({
          type: 'success',
          title: 'Data Saved success!'
        });
      }, (err) => {
        console.log(err);
        this.formData.delete('name');
        this.formData.delete('email');
        this.formData.delete('phoneNum');
        this.formData.delete('profileImg');
        const toast = Swal.mixin({
          toast: true,
          position: 'bottom',
          showConfirmButton: false,
          timer: 3000
        });
        toast.fire({
          type: 'error',
          title: 'Failed Saving Data?'
        });
      }
    )
  }

  // Get Employee Data
  getEmpData() {
    this.empSrv.getEmpData().subscribe(
      (res) => {
        console.log(res);
        this.employees = res;
      }, (err) => {
        console.log(err);
      }
    )
  }

  // Delete One Employee Data
  deleteOneEmp(empId) {
    this.route.params.subscribe(
      (res) => {
        console.log(res);
        this.empId = res.empId;
      }
    );
    this.empSrv.deteleEmpOne(empId).subscribe(
      (res) => {
        console.log(res);
        res = this.employees;
        const Toast = Swal.mixin({
          toast: true,
          position: 'center',
          showConfirmButton: false,
          timer: 3000
        });
        Toast.fire({
          type: 'success',
          title: 'Delete success!'
        });
      }, (err) => {
        console.log(err);
        const Toast = Swal.mixin({
          toast: true,
          position: 'center',
          showConfirmButton: false,
          timer: 3000
        });
        Toast.fire({
          type: 'error',
          title: 'Delete failed?'
        });
      }
    );
    this.getEmpData();
  }

}