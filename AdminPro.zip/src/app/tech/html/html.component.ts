import { Component, OnInit } from '@angular/core';
import * as $ from 'jquery';

@Component({
  selector: 'app-html',
  templateUrl: './html.component.html',
  styleUrls: ['./html.component.css']
})
export class HtmlComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    //made by vipul mirajkar thevipulm.appspot.com
    var TxtType = function(el, toRotate, period) {
      this.toRotate = toRotate;
      this.el = el;
      this.loopNum = 0;
      this.period = parseInt(period, 10) || 2000;
      this.txt = '';
      this.tick();
      this.isDeleting = false;
    };

    TxtType.prototype.tick = function() {
      var i = this.loopNum % this.toRotate.length;
      var fullTxt = this.toRotate[i];

      if (this.isDeleting) {
      this.txt = fullTxt.substring(0, this.txt.length - 1);
      } else {
      this.txt = fullTxt.substring(0, this.txt.length + 1);
      }

      this.el.innerHTML = '<span class="wrap">'+this.txt+'</span>';

      var that = this;
      var delta = 200 - Math.random() * 100;

      if (this.isDeleting) { delta /= 2; }

      if (!this.isDeleting && this.txt === fullTxt) {
      delta = this.period;
      this.isDeleting = true;
      } else if (this.isDeleting && this.txt === '') {
      this.isDeleting = false;
      this.loopNum++;
      delta = 500;
      }

      setTimeout(function() {
      that.tick();
      }, delta);
    };

    window.onload = function() {
      var elements = document.getElementsByClassName('typewrite');
      for (var i=0; i<elements.length; i++) {
          var toRotate = elements[i].getAttribute('data-type');
          var period = elements[i].getAttribute('data-period');
          if (toRotate) {
            new TxtType(elements[i], JSON.parse(toRotate), period);
          }
      }
      // INJECT CSS
      var css = document.createElement("style");
      css.type = "text/css";
      css.innerHTML = ".typewrite > .wrap { border-right: 0.08em solid #fff}";
      document.body.appendChild(css);
    };

    // Accordion Script
    var accordion = $('body').find('[data-behavior="accordion"]');
    var expandedClass = 'is-expanded';

    $.each(accordion, function () { // loop through all accordions on the page

      var accordionItems = $(this).find('[data-binding="expand-accordion-item"]');

      $.each(accordionItems, function () { // loop through all accordion items of each accordion
        var $this = $(this);
        var triggerBtn = $this.find('[data-binding="expand-accordion-trigger"]');

        var setHeight = function (nV) {
          // set height of inner content for smooth animation
          var innerContent = nV.find('.accordion__content-inner')[0],
            maxHeight = $(innerContent).outerHeight(),
            content = nV.find('.accordion__content')[0];

          if (!content.style.height || content.style.height === '0px') {
            $(content).css('height', maxHeight);
          } else {
            $(content).css('height', '0px');
          }
        };

        var toggleClasses = function (event) {
          var clickedItem = event.currentTarget;
          var currentItem = $(clickedItem).parent();
          var clickedContent = $(currentItem).find('.accordion__content')
          $(currentItem).toggleClass(expandedClass);
          setHeight(currentItem);

          if ($(currentItem).hasClass('is-expanded')) {
            $(clickedItem).attr('aria-selected', 'true');
            $(clickedItem).attr('aria-expanded', 'true');
            $(clickedContent).attr('aria-hidden', 'false');

          } else {
            $(clickedItem).attr('aria-selected', 'false');
            $(clickedItem).attr('aria-expanded', 'false');
            $(clickedContent).attr('aria-hidden', 'true');
          }
        }

        triggerBtn.on('click', event, function (e) {
          e.preventDefault();
          toggleClasses(event);
        });

        // open tabs if the spacebar or enter button is clicked whilst they are in focus
        $(triggerBtn).on('keydown', event, function (e) {
          if (e.keyCode === 13 || e.keyCode === 32) {
            e.preventDefault();
            toggleClasses(event);
          }
        });
      });

    });
  }
  
}
