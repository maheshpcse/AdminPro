import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { AuthServicesService } from 'src/app/services/auth-service/auth-services.service';
import * as $ from 'jquery';
import { Reviews } from 'src/app/shared/reviews.model';
import { Router, ActivatedRoute } from '@angular/router';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-home-page',
  templateUrl: './home-page.component.html',
  styleUrls: ['./home-page.component.css']
})
export class HomePageComponent implements OnInit {
 
  selected:any;
  
  reviews;
  
  review:any = {
    name:'',
    email: '',
    review: '',
    rating: ''
  }

  constructor(
    private authSrv: AuthServicesService,
    private router: Router,
    private route: ActivatedRoute
  ) { }

  reviewsList() {
    this.authSrv.getAllReviews().subscribe(
      (res) => {
        console.log(res);
        this.reviews = res;
      }, (err) => {
        console.log(err);
      }
    );
  }

  // Add Reviews
  addReview() {
    this.review.rating = +(this.selected);
    console.log(this.review);
    
    this.authSrv.addReview(this.review).subscribe(
      (res) => {
        console.log(res);
        this.review = res;
        const toast = Swal.mixin({
          toast: true,
          position: 'center',
          showConfirmButton: false,
          timer: 3000
        });
        toast.fire({
          type: 'success',
          title: 'Review Added'
        });
      }, (err) => {
        console.log(err);
          const toast = Swal.mixin({
            toast: true,
            position: 'bottom',
            showConfirmButton: false,
            timer: 3000
          });
          toast.fire({
            type: 'error',
            title: 'Review Not Added'
          });
      }
    );
    this.reviewsList();
  }

  ngOnInit() {
    this.reviewsList();

  
    function add(ths, sno) {

      for (var i = 1; i <= 5; i++) {
        var cur = document.getElementById("star" + i)
        cur.className = "fa fa-star"
      }

      for (var i = 1; i <= sno; i++) {
        var cur = document.getElementById("star" + i)
        if (cur.className == "fa fa-star") {
          cur.className = "fa fa-star checked"
        }
      }
      
    }

    // rating
    $(document).ready(function ($) {
 
      $(".btnrating").on('click', (function (e) {

        var previous_value = $("#selected_rating").val();

        var selected_value = $(this).attr("data-attr");
        $("#selected_rating").val(selected_value);

        $(".selected-rating").empty();
        $(".selected-rating").html(selected_value);

        var i, ix;

        for (i = 1; i <= selected_value; ++i) {
          $("#rating-star-" + i).toggleClass('btn-warning');
          $("#rating-star-" + i).toggleClass('btn-default');
        }

        for (ix = 1; ix <= previous_value; ++ix) {
          $("#rating-star-" + ix).toggleClass('btn-warning');
          $("#rating-star-" + ix).toggleClass('btn-default');
        }
      }));
    });
    
    // ScrollDown Arrow
    $(function() {
      $('a[href*=#]').on('click', function(e) {
        e.preventDefault();
        $('html, body').animate({ scrollTop: $($(this).attr('href')).offset().top}, 500, 'linear');
      });
    });
  }

  isClick:Boolean = false;
  display = false;
  id:any;
  
  onSelect(id,display) {
    this.id = id;
    this.display= !display
    // console.log(this.display);
  }

  ScrollDownArrow() {
    $(window).on("arrow", function() {
      var scrollHeight = $(document).height();
      var scrollPosition = $(window).height() + $(window).scrollTop();
      if ((scrollHeight - scrollPosition) / scrollHeight === 500) {
          // when scroll to bottom of the page
      }
    });
  }
}
