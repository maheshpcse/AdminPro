import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthServicesService } from './services/auth-service/auth-services.service';
import Swal from 'sweetalert2';
import * as $ from 'jquery';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'AdminPro';

  constructor( ) { }

  ngOnInit() {
    $(function arrow() {
      $('#arrow').on('click', function(e) {
        e.preventDefault();
        $('html, body').animate({ scrollTop: $($(this).attr('#arrow')).offset().top}, 500, 'linear');
      });
    });

   //Thanks to: http://www.webtipblog.com/adding-scroll-top-button-website/

    $(document).ready(function () {

      $(function () {

        $(document).on('scroll', function () {

          if ($(window).scrollTop() > 100) {
            $('.scroll-top-wrapper').addClass('show');
          } else {
            $('.scroll-top-wrapper').removeClass('show');
          }
        });

        $('.scroll-top-wrapper').on('click', scrollToTop);
      });

      function scrollToTop() {
        var verticalOffset;
        var element;
        var offset;
        var offsetTop;
        verticalOffset = typeof (verticalOffset) != 'undefined' ? verticalOffset : 0;
        element = $('body');
        offset = element.offset();
        offsetTop = offset.top;
        $('html, body').animate({
          scrollTop: offsetTop
        }, 500, 'linear');
      }

    });
    
  }
  
}