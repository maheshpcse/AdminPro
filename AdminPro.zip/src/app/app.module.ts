import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule }    from '@angular/common/http';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { 
  MatFormFieldModule, 
  MatCardModule, 
  MatInputModule, 
  MatIconModule,
  MatToolbarModule,
  MatSelectModule,
  MatButtonModule, 
  MatCheckboxModule
} from '@angular/material';
import { MaterialFileInputModule } from 'ngx-material-file-input';
import { FileSelectDirective } from 'ng2-file-upload/ng2-file-upload';

import { AppRoutingModule } from './app-routing/app-routing.module';
import { AppComponent } from './app.component';
import { HeaderNavComponent } from './header/header-nav/header-nav.component';
import { HomePageComponent } from './home/home-page/home-page.component';
import { ProfileComponent } from './admin/profile/profile.component';
import { LoginComponent } from './access/login/login.component';
import { SignupComponent } from './access/signup/signup.component';
import { AllusersComponent } from './admin/allusers/allusers.component';
import { SettingsComponent } from './admin/settings/settings.component';
import { AuthGuardService } from './services/auth-guard.service';
import { UserProfileViewComponent } from './admin/allusers/user-profile-view/user-profile-view.component';
import { NotificationsComponent } from './admin/notifications/notifications.component';
import { NotFoundComponent } from './not-found/not-found.component';
import { ContactComponent } from './contact/contact.component';
import { ViewProfileComponent } from './employee/view-profile/view-profile.component';
import { HtmlComponent } from './tech/html/html.component';
import { CssComponent } from './tech/css/css.component';
import { BootstrapComponent } from './tech/bootstrap/bootstrap.component';
import { AboutComponent } from './about/about.component';
import { JavascriptComponent } from './tech/javascript/javascript.component';
import { MongodbComponent } from './tech/mean/mongodb/mongodb.component';
import { ExpressComponent } from './tech/mean/express/express.component';
import { AngularComponent } from './tech/mean/angular/angular.component';
import { NodejsComponent } from './tech/mean/nodejs/nodejs.component';
import { FullstackComponent } from './tech/fullstack/fullstack.component';
import { AuthServicesService } from './services/auth-service/auth-services.service';
import { TokenInterceptorService } from './services/token-interceptor/token-interceptor.service';
import { FooterComponent } from './footer/footer.component';
import { FaqComponent } from './faq/faq.component';
import { DatabaseComponent } from './tech/database/database.component';
import { FilmsComponent } from './films/films.component';
import { ViewFilmComponent } from './films/view-film/view-film.component';
import { FilmsServicesService } from './services/films-service/films-services.service';
import { EmployeesComponent } from './employees/employees.component';
import { NewsComponent } from './news/news.component';
import { StudentsComponent } from './students/students.component';
import { AllHotelsComponent } from './hotels/all-hotels/all-hotels.component';
import { BookHotelComponent } from './hotels/book-hotel/book-hotel.component';
import { ManageHotelComponent } from './hotels/manage-hotel/manage-hotel.component';
import { AddHotelComponent } from './hotels/manage-hotel/add-hotel/add-hotel.component';
import { UpdateHotelComponent } from './hotels/manage-hotel/update-hotel/update-hotel.component';
import { DeleteHotelComponent } from './hotels/manage-hotel/delete-hotel/delete-hotel.component';
import { ChatComponent } from './chat/chat.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderNavComponent,
    HomePageComponent,
    LoginComponent,
    SignupComponent,
    ProfileComponent,
    AllusersComponent,
    SettingsComponent,
    UserProfileViewComponent,
    NotificationsComponent,
    NotFoundComponent,
    ContactComponent,
    ViewProfileComponent,
    HtmlComponent,
    CssComponent,
    BootstrapComponent,
    AboutComponent,
    JavascriptComponent,
    MongodbComponent,
    ExpressComponent,
    AngularComponent,
    NodejsComponent,
    FullstackComponent,
    FooterComponent,
    FaqComponent,
    DatabaseComponent,
    FilmsComponent,
    ViewFilmComponent,
    EmployeesComponent,
    FileSelectDirective,
    NewsComponent,
    StudentsComponent,
    AllHotelsComponent,
    BookHotelComponent,
    ManageHotelComponent,
    AddHotelComponent,
    UpdateHotelComponent,
    DeleteHotelComponent,
    ChatComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    Ng2SearchPipeModule,
    // Material modules
    MatFormFieldModule, 
    MatCardModule, 
    MatInputModule, 
    MatIconModule,
    MatToolbarModule,
    MatSelectModule,
    MatButtonModule, 
    MatCheckboxModule,
    // Load file module
    MaterialFileInputModule
  ],
  providers: [AuthGuardService,AuthServicesService,FilmsServicesService,TokenInterceptorService],
  bootstrap: [AppComponent]
})
export class AppModule { }
