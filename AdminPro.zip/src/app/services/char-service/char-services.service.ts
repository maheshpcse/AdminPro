import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CharServicesService {

  private charUrl = `http://localhost:3000/api/allactors/`;
  characters = [{}, {}, {}, {}];

  constructor(private http: HttpClient) { }

  // Get All Characters
  getAllCharacters() {
    return this.http.get(this.charUrl);
  }

  // Get One Character Data By Id
  getOneCharById(charId) {
    return this.http.get(this.charUrl + 'id/' + charId);
  }
}
