import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class AuthServicesService {

  role = localStorage.getItem('role');

  private LoginUrl = `http://localhost:3000/api/login`;
  private RegisterUrl = `http://localhost:3000/api/register`;

  private UsersUrl = `http://localhost:3000/api/allusers/`;
  users = [{}, {}, {}, {}];

  private reviewsUrl = `http://localhost:3000/api/`;
  reviews = [{}, {}, {}, {}];

  constructor(private http: HttpClient) {}

  addReview(api) {
    return this.http.post < any > (this.reviewsUrl + 'addreview/', api);
  }

  getAllReviews() {
    return this.http.get(this.reviewsUrl + 'allreviews/');
  }

  usersDetails() {
    return this.http.get(this.UsersUrl);
  }

  userOneById(userId) {
    console.log('User Id is found');
    return this.http.get(this.UsersUrl + 'id/' + userId);
  }
  
  sendRole(role) {
    this.role = role;
  }

  userOneByName(userName) {
    console.log('Username is found');
    return this.http.get(this.UsersUrl + 'username/' + userName);
  }

  userOneUpdateById(userId, admin) {
    console.log('User Details is updated');
    return this.http.post(this.UsersUrl + 'update/' + userId, admin);
  }

  userOneDeleteById(userId) {
    // console.log('User one is delete successfully');
    return this.http.get(this.UsersUrl + 'delete/' + userId);
  }

  uploadProfileById(userId, data) {
    return this.http.post(this.UsersUrl + 'file/' + userId,data);
  }

  updatePasswordById(userId, data) {
    return this.http.post(this.UsersUrl + 'password/' + userId,data);
  }

  userLogin(api) {
    return this.http.post < any > (this.LoginUrl, api);
  }

  getRole() {
    return localStorage.getItem('role');
  }
  
  userRegistration(api) {
    return this.http.post < any > (this.RegisterUrl, api);
  }

  getToken() {
    return localStorage.getItem('token');
  }
  getUserType() {
    return localStorage.getItem('role');
  }

  getUserPayload() {
    var token = this.getToken();
    if (token) {
      var userPayload = atob(token.split('.')[1]);
      return JSON.parse(userPayload);
    }
    else
      return null;
  }

  isLoggedIn(): boolean {
    // if (localStorage.getItem('token')) {
    //   return true; 
    // } else {
    //   return false;
    // }
    var userPayload = this.getUserPayload();
    if (userPayload)
      return userPayload.exp > Date.now() / 1000;
    else
      return false;
  }
}