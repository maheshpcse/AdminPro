import { TestBed } from '@angular/core/testing';

import { HotelServicesService } from './hotel-services.service';

describe('HotelServicesService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: HotelServicesService = TestBed.get(HotelServicesService);
    expect(service).toBeTruthy();
  });
});
