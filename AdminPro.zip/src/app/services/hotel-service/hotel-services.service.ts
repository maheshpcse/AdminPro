import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class HotelServicesService {

  // node serve url
  private hotelUrl = 'http://localhost:3000/api/hotels/';
  private hotelsAllUrl = 'http://localhost:3000/api/allhotels';
  hotels = [{}, {}, {}, {}];

  constructor(private http: HttpClient) {}

  getAllHotels() {
    return this.http.get(this.hotelsAllUrl);
  }

  getHotels() {
    return this.http.get(this.hotelUrl);
  }

  getHotelsByFilter(offset: number, count: number) {
    return this.http.get(this.hotelUrl + '?offset = ' + offset + '&count= ' + count);
  }

  getOneHotel(hotelId) {
    console.log('Hotel Id is found');
    return this.http.get(this.hotelUrl + 'id/' + hotelId);
  }

  getOneHotelByName(hotelName) {
    console.log('Hotel Name is found');
    return this.http.get(this.hotelsAllUrl + 'name/' + hotelName);
  }
}
