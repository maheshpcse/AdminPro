import { Injectable, Injector } from '@angular/core';
import { AuthServicesService } from '../auth-service/auth-services.service';

@Injectable({
  providedIn: 'root'
})
export class TokenInterceptorService {

  constructor(private _injector:Injector) { }

  intercept(req,next){
    let authSrv = this._injector.get(AuthServicesService) ;
    let tokenizedReq = req.clone({
      setHeaders:{
       'x-access-token':`${authSrv.getToken()}`
      }
    });
    return next.handle(tokenizedReq)
  }
}
