import { TestBed } from '@angular/core/testing';

import { FilmsServicesService } from './films-services.service';

describe('FilmsServicesService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: FilmsServicesService = TestBed.get(FilmsServicesService);
    expect(service).toBeTruthy();
  });
});
