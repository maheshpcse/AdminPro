import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class FilmsServicesService {

  private FilmsUrl = `http://localhost:3000/api/allfilms/`;
  films = [{}, {}, {}, {}];

  constructor(private http: HttpClient) { }

  // Get All Films Data
  getAllFilms() {
    return this.http.get(this.FilmsUrl);
  }

  // Get One Film Data By Id
  getOneFilmById(filmId) {
    console.log("Film Id is found");
    return this.http.get(this.FilmsUrl + 'film/' + filmId);
  }
}