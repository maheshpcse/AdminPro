import { Injectable } from '@angular/core';
import { AuthServicesService } from './auth-service/auth-services.service';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthGuardService {

  constructor(
    public authSrv: AuthServicesService,
    public router: Router
  ) { }

  canActivate(): boolean {
    if (!this.authSrv.isLoggedIn()) {
      this.router.navigateByUrl('/home');
      return false;
    }
    return true;
  }
}
