import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class EmployeeServicesService {

  private EmpUrl = `http://localhost:3000/api/save/`;

  private getEmpUrl = `http://localhost:3000/api/emps/`;
  employees = [{}, {}, {}, {}];

  private stuUrl = `http://localhost:3000/api/student/`;

  constructor(private http: HttpClient) { }

  // Save Employee Data
  saveEmpData(api) {
    console.log(api.get('profileImg'));
    return this.http.post < any > (this.EmpUrl ,api);
  }

  // Get All EMployees Data
  getEmpData() {
    return this.http.get(this.getEmpUrl);
  }

  // Delete One Employee Data
  deteleEmpOne(empId) {
    return this.http.get(this.getEmpUrl + 'delete/' + empId);
  }

  saveStudentData(api) {
    return this.http.post <any>(this.stuUrl, api);
  }
}