import { Component, OnInit } from '@angular/core';
import { Students } from '../shared/students.model';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-students',
  templateUrl: './students.component.html',
  styleUrls: ['./students.component.css']
})
export class StudentsComponent implements OnInit {

  // studnets: Students[] = [];

  studentForm: FormGroup;
  submitted = false;

  Student: any = {
    firstname: '',
    lastname: '',
    username: '',
    email: '',
    password: '',
    phonenumber: '',
    image: ''
  }

  Image: any;

  constructor() { }

  ngOnInit() {
    this.studentForm = new FormGroup({
      firstname: new FormControl('', Validators.required),
      lastname: new FormControl('', Validators.required),
      username: new FormControl('', Validators.required),
      email: new FormControl('', [Validators.required, Validators.email]),
      password: new FormControl('', [Validators.required, Validators.minLength(6)]),
      phonenumber: new FormControl('', Validators.required)
    });
  }

  get f() {
    return this.studentForm.controls;
  }

  onFileSelected(event) {
    this.Image = event.target.files[0];
    console.log(this.Image);
  }

  onSubmit() {
    this.submitted = true;
    if(this.studentForm.invalid) {
      return;
    } else {
      console.log(this.studentForm.value,this.Image);
    }
  }

  onReset() {
    this.Student = '';
    console.log(this.Student);
    console.clear();
  }
}
