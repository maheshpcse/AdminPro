import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { RoomsList } from 'src/app/shared/Hotel Data/rooms.model';
import { ReviewList } from 'src/app/shared/Hotel Data/reviews.model';
import { ServicesList } from 'src/app/shared/Hotel Data/services.model';
import { HotelData } from 'src/app/shared/Hotel Data/hoteldata.model';

@Component({
  selector: 'app-add-hotel',
  templateUrl: './add-hotel.component.html',
  styleUrls: ['./add-hotel.component.css']
})
export class AddHotelComponent implements OnInit {

  // add hotel details
  @ViewChild('hotelNameInput',{ static: false }) hotelNameInputRef: ElementRef;
  @ViewChild('hotelRatingInput',{ static: false }) hotelRatingInputRef: ElementRef;
  @ViewChild('hotelDescInput', { static: false }) hotelDescInputRef: ElementRef;
  @ViewChild('currencyInput', { static: false }) currencyInputRef: ElementRef;
  @ViewChild('hotelAddrInput', { static: false }) hotelAddrInputRef: ElementRef;
  @ViewChild('latInput', { static: false }) latInputRef: ElementRef;
  @ViewChild('lonInput', { static: false }) lonInputRef: ElementRef;
  
  // add image for hotel
  imageInput: any;
  @ViewChild('hotelImageInput', { static: false }) hotelImageInputRef: ElementRef;
  
  // add rooms for hotel
  @ViewChild('roomTypeInput', { static: false }) roomTypeInputRef: ElementRef;
  @ViewChild('roomDescInput', { static: false }) roomDescInputRef: ElementRef;
  @ViewChild('roomsAvalInput', { static: false }) roomsAvalInputRef: ElementRef;
  @ViewChild('roomCostInput', { static: false }) roomCostInputRef: ElementRef;
  rooms: RoomsList[] = [];

  // add reviews
  @ViewChild('nameInput', { static: false }) nameInputRef: ElementRef;
  @ViewChild('reviewInput', { static: false }) reviewInputRef: ElementRef;
  @ViewChild('ratingInput', { static: false }) ratingInputRef: ElementRef;
  reviews: ReviewList[] = [];

  // add services
  @ViewChild('servicesInput', { static: false }) servicesInputRef: ElementRef;
  services: ServicesList[] = [];
  topic= {
    name:''
  }
  hotelSave: HotelData[] = [
    // new HotelData(
    //   'http://blog.hltt.in/wp-content/uploads/2014/07/le-meridien-hotel-bangalore.jpg',
    //   'Le-meridien Hotel',
    //   3.5,
    //   'Best hotel in Bangalore',
    //   'HUF',
    //   'Single Suit Room',
    //   'This rooms are nice to stay',
    //   20,
    //   50000,
    //   'Brundavanam Gardens, Bangalore',
    //   54.9989,
    //   21.9897,
    //   ['wifi','car'],
    //   'James',
    //   'Nice hotel',
    //   4.5
    // )
  ];
  
  constructor() { }

  ngOnInit() {
  }

  // add images for hotel
  processFile(event) {
    const file: File = event.target.files[0];
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = ()=>{
      this.imageInput = reader.result;
    }
  }

  // add rooms for hotel
  onAddRooms() {
    const RoomType = this.roomTypeInputRef.nativeElement.value;
    const RoomDesc = this.roomDescInputRef.nativeElement.value;
    const RoomsAval = this.roomsAvalInputRef.nativeElement.value;
    const RoomCost = this.roomCostInputRef.nativeElement.value;

    const newRoom = new RoomsList(RoomType, RoomDesc, RoomsAval, RoomCost);
    this.rooms.push(newRoom);
    console.log(this.rooms);
  }
  onRemoveRooms() {
    this.rooms.pop();
  }

  // add reviews for hotel
  onAddReview() {
    const Name = this.nameInputRef.nativeElement.value;
    const Review = this.reviewInputRef.nativeElement.value;
    const Rating = this.ratingInputRef.nativeElement.value;

    const newReiew = new ReviewList(Name, Review, Rating);
    this.reviews.push(newReiew);
    console.log(this.reviews);
  }
  onRemoveReview() {
    this.reviews.pop();
  }

  // add services for hotel
  onAddService() {
    const serviceName = this.servicesInputRef.nativeElement.value;

    const newService = new ServicesList(serviceName);
    this.services.push(newService);
    console.log(this.services);
    
  }
  onRemoveService() {
    this.services.pop();
  }

  // Hotel data save
  onSaveData() {
    const HotelName = this.hotelNameInputRef.nativeElement.value;
    const HotelRating = this.hotelRatingInputRef.nativeElement.value;
    const HotelDesc = this.hotelDescInputRef.nativeElement.value;
    const HotelCurrency = this.currencyInputRef.nativeElement.value;

    const HotelAddress = this.hotelAddrInputRef.nativeElement.value;
    const Latitude = this.latInputRef.nativeElement.value;
    const Longitude = this.lonInputRef.nativeElement.value;
    console.log(HotelName);
    console.log(HotelRating);
    console.log(HotelDesc);
    console.log(HotelCurrency);
    console.log(this.rooms);
    console.log(HotelAddress);
    console.log(Latitude);
    console.log(Longitude);
    console.log(this.services);
    console.log(this.reviews);
    
    const HotelSaved = new HotelData(
      this.imageInput,
      HotelName, 
      HotelRating, 
      HotelDesc, 
      HotelCurrency,
      this.rooms,
      HotelAddress, 
      Latitude, 
      Longitude, 
      this.services,
      this.reviews
    );
    this.hotelSave.push(HotelSaved);
  }
  onRemoveData() {
    this.hotelSave.pop();
  }
  onResetData() {
    this.hotelNameInputRef.nativeElement.value = "";
    this.hotelRatingInputRef.nativeElement.value = "";
    this.hotelDescInputRef.nativeElement.value = "";
    this.currencyInputRef.nativeElement.value = "";

    this.roomTypeInputRef.nativeElement.value = "";
    this.roomDescInputRef.nativeElement.value = "";
    this.roomsAvalInputRef.nativeElement.value = "";
    this.roomCostInputRef.nativeElement.value = "";

    this.hotelAddrInputRef.nativeElement.value = "";
    this.latInputRef.nativeElement.value = "";
    this.lonInputRef.nativeElement.value = "";

    this.servicesInputRef.nativeElement.value = "";
    this.nameInputRef.nativeElement.value = "";
    this.reviewInputRef.nativeElement.value = "";
    this.ratingInputRef.nativeElement.value = "";
  }
}
