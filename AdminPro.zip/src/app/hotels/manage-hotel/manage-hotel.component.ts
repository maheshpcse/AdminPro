import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-hotel',
  templateUrl: './manage-hotel.component.html',
  styleUrls: ['./manage-hotel.component.css']
})
export class ManageHotelComponent implements OnInit {

  addMyHotel: string;
  display: string = "";

  constructor() { }

  ngOnInit() {
  }

  onSelect(submit: string) {
    this.display = submit;
  }
  
  onClear() {
    this.display = "";
  }

}
