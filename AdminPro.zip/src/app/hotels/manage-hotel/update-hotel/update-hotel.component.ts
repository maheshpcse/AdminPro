import { Component, OnInit } from '@angular/core';
import { HotelServicesService } from 'src/app/services/hotel-service/hotel-services.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-update-hotel',
  templateUrl: './update-hotel.component.html',
  styleUrls: ['./update-hotel.component.css']
})
export class UpdateHotelComponent implements OnInit {

  hotels;
  hotelLength = 0;
  private offset:number = 0;
  private count:number = 3;

  searchText;

  constructor(
    private hotelSrv:HotelServicesService, 
    private route:ActivatedRoute
  ) { }

  ngOnInit() {
    this.hotelSrv.getAllHotels().subscribe(
      (res)=>{
        console.log(res);
        this.hotels = res;
      },(err)=>{
        console.log(err);
      }
    );
  }
}
