import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-book-hotel',
  templateUrl: './book-hotel.component.html',
  styleUrls: ['./book-hotel.component.css']
})
export class BookHotelComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
