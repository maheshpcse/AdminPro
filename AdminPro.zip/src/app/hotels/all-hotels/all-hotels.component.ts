import { Component, OnInit } from '@angular/core';
import { HotelServicesService } from 'src/app/services/hotel-service/hotel-services.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-all-hotels',
  templateUrl: './all-hotels.component.html',
  styleUrls: ['./all-hotels.component.css']
})
export class AllHotelsComponent implements OnInit {

  hotels;
  hotelLength = 0;
  private offset: Number = 0;
  private count: Number = 3;

  searchText;
  
  constructor(
    private hotelSrv: HotelServicesService,
    private route: ActivatedRoute
  ) {}

  ngOnInit() {
    this.hotelSrv.getHotels().subscribe(
      (res) => {
        console.log(res);
        this.hotels = res;
      }, (err) => {
        console.log(err);
      }
    );
  }

  // get hotels by filter, 5 records everytime
  getHotelsByFilter(offset: number, count: number) {
    this.offset = offset;
    this.count = count;
    if (this.offset >= 0) {
      this.hotelSrv.getHotelsByFilter(offset, count)
        .subscribe(
          (res: any) => {
            console.log(res);
            if (res.length > 0) {
              this.hotels = res;
            } else {
              offset = 0;
            }
          }, (err) => {
            console.log(err);
          });
    } else {
      this.offset = 0;
      this.count = 4;
    }
  }
}
