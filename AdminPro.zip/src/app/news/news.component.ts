import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { EmployeeServicesService } from '../services/employee-service/employee-services.service';
import { ActivatedRoute } from '@angular/router';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-news',
  templateUrl: './news.component.html',
  styleUrls: ['./news.component.css']
})
export class NewsComponent implements OnInit {

  // students: any;

  studentsData :any = {
    name: '',
    email: '',
    img: ''
  }

  // Image: any;
  @ViewChild("fileInput", {static: false}) fileInputRef: ElementRef;
  
  formData = new FormData();

  constructor(
    private empSrv: EmployeeServicesService,
    private route: ActivatedRoute
  ) { }

  ngOnInit() {
  }

  onFileSelected(event) {
    console.log(event.target.files[0]);    
    this.formData.append('img', event.target.files[0]);
  }

  saveStudentData() {
    console.log(this.studentsData);
    this.formData.append('name', this.studentsData.name);
    this.formData.append('email', this.studentsData.email);
    this.empSrv.saveStudentData(this.formData).subscribe(
      (res) => {
        console.log(res);
        this.studentsData = res;
        this.formData.delete('name');
        this.formData.delete('email');
        this.formData.delete('img');
        const toast = Swal.mixin({
          toast: true,
          position: 'center',
          showConfirmButton: false,
          timer: 3000
        });
        toast.fire({
          type: 'success',
          title: 'Data Saved success!'
        });
      }, (err) => {
        console.log(err);
        this.formData.delete('name');
        this.formData.delete('email');
        this.formData.delete('img');
        const toast = Swal.mixin({
          toast: true,
          position: 'bottom',
          showConfirmButton: false,
          timer: 3000
        });
        toast.fire({
          type: 'error',
          title: 'Failed Saving Data?'
        });
      }
    )
  }  
}