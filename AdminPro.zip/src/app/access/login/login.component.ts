import { Component, OnInit, OnDestroy } from '@angular/core';
import { AuthServicesService } from 'src/app/services/auth-service/auth-services.service';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
import { FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit, OnDestroy {

  hide = true;

  user: any;
  pass: any;
  
  email = new FormControl('', [
    Validators.required,
    Validators.email
  ]);

  users:Object = {
    email:'',
    password:''
  };

  constructor(
    private authSrv:AuthServicesService,
    private router:Router
  ) { }

  ngOnInit() {
  //   this.user = setTimeout(() => {
  //     const Toast = Swal.mixin({
  //       toast: true,
  //       position: 'center',
  //       showConfirmButton: false,
  //       timer: 3000
  //     });
  //     Toast.fire({
  //       type: 'warning',
  //       title: 'Hey! You forgot to Loggedin to your account!'
  //     });
  //   }, 10000);
  //  this.pass = setTimeout(() => {
  //     this.router.navigate(['/home']);
  //   }, 12000);
  }

  // enter(data) {
  //   if(data) {
  //     clearTimeout(this.user);
  //     clearTimeout(this.pass);
  //   }
  // }

  getErrorMessage() {
    return this.email.hasError('required') ? 'You must enter a value' :
      this.email.hasError('email') ? 'Not a valid email' :
        '';
  }

  loginUser() {
    console.log(this.users);
    this.authSrv.userLogin(this.users).subscribe(
      (res)=>{
        console.log(res);
        this.users = res;
        localStorage.setItem('token',res.payLoad.token);
        localStorage.setItem('role', res.payLoad.role);
        localStorage.setItem('userId',res.payLoad.userId);
        localStorage.setItem('username',res.payLoad.username);
        console.log(res.payLoad.role);
        this.router.navigateByUrl('/home');
        const Toast = Swal.mixin({
          toast: true,
          position: 'top-end',
          showConfirmButton: false,
          timer: 3000
        });
        Toast.fire({
          type: 'success',
          title: 'Signed in successfully'
        });
      },(err)=>{
        console.log(err);
        const Toast = Swal.mixin({
          toast: true,
          position: 'bottom',
          showConfirmButton: false,
          timer: 3000
        });
        Toast.fire({
          type: 'error',
          title: 'Login failed!'
        });
      }
    )
  }

  ngOnDestroy(){
    console.log("Login Component Was Destroyed");
    clearTimeout(this.user);
    clearTimeout(this.pass);
  }
}
