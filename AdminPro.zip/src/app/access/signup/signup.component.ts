import { Component, OnInit } from '@angular/core';
import Swal from 'sweetalert2';
import { AuthServicesService } from 'src/app/services/auth-service/auth-services.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Validators, FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  hide = true;

  email = new FormControl('', [
    Validators.required,
    Validators.email
  ]);

  Image: any;
  formDoc;

  registrationData: Object = {
    firstname: '',
    lastname: '',
    dob: '',
    designation: '',
    username: '',
    email: '',
    password: '',
    address: '',
    role: '',
    phoneNumber: '',
  }

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private authSrv: AuthServicesService
  ) { }

  ngOnInit() {
    this.formDoc = new FormGroup({
      basicfile: new FormControl()
    });
  }

  onFileChange(event) {
    console.log(event.target.files[0]);
    var reader = new FileReader();
    var file = event.target.files[0];
    reader.readAsDataURL(file);
    reader.onload = () => {
      this.Image = reader.result;
    }
  }

  getErrorMessage() {
    return this.email.hasError('required') ? 'You must enter a value' :
      this.email.hasError('email') ? 'Not a valid email' :
        '';
  }

  registrationUser() {
    this.authSrv.userRegistration(this.registrationData)
      .subscribe(
        (res) => {
          console.log(res);
          this.registrationData = res;
          localStorage.setItem('token', res.payLoad.token);
          localStorage.setItem('role', res.payLoad.role);
          localStorage.setItem('userId', res.payLoad.userId);
          localStorage.setItem('username', res.payLoad.username);
          this.router.navigateByUrl('/home');
          const toast = Swal.mixin({
            toast: true,
            position: 'center',
            showConfirmButton: false,
            timer: 3000
          });
          toast.fire({
            type: 'success',
            title: 'Registration success!'
          });
        }, (err) => {
          console.log(err);
          const toast = Swal.mixin({
            toast: true,
            position: 'bottom',
            showConfirmButton: false,
            timer: 3000
          });
          toast.fire({
            type: 'error',
            title: 'Registration failed?'
          });
        }
      )
  }
  resetAll() {
    this.registrationData = {};
  }
}
