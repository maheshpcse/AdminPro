import { Component, OnInit } from '@angular/core';
import * as $ from 'jquery';

@Component({
  selector: 'app-faq',
  templateUrl: './faq.component.html',
  styleUrls: ['./faq.component.css']
})
export class FaqComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    $('.accordion-item .heading').on('click', function (e) {
      e.preventDefault();

      // Add the correct active class
      if ($(this).closest('.accordion-item').hasClass('active')) {
        // Remove active classes
        $('.accordion-item').removeClass('active');
      } else {
        // Remove active classes
        $('.accordion-item').removeClass('active');

        // Add the active class
        $(this).closest('.accordion-item').addClass('active');
      }

      // Show the content
      var $content = $(this).next();
      $content.slideToggle(100);
      $('.accordion-item .content').not($content).slideUp('fast');
    });
  
  }

}
