import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthServicesService } from 'src/app/services/auth-service/auth-services.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-view-profile',
  templateUrl: './view-profile.component.html',
  styleUrls: ['./view-profile.component.css']
})
export class ViewProfileComponent implements OnInit {

  userId = localStorage.getItem('userId');

  // File Upload
  formData = new FormData();
  @ViewChild("fileInput", {static: false}) fileInputRef:ElementRef;

  // Employee Profile Fields
  employee:Object = {
    profileImg: '',
    firstname: '',
    lastname: '',
    dob:'',
    designation: '',
    username: '',
    email: '',
    address: '',
    role: '',
    phoneNumber: ''
  };

  // Employee Profile Updating Fields
  newEmp:Object = {
    firstname: '',
    lastname: '',
    dob:'',
    designation: '',
    username: '',
    email: '',
    password: '',
    confirm_password: '',
    address: '',
    role: '',
    phoneNumber: ''
  }

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private authSrv: AuthServicesService
  ) { }

  ngOnInit() {
    console.log(this.userId);
    this.employeeProfile();
  }

  onFileSelected(event){
    console.log(event.target.files[0]);
    this.formData.append('image', event.target.files[0]);
  }

  // Upload Image
  uploadImage() {
    console.log(this.formData.get('image'));
    this.authSrv.uploadProfileById(this.userId, this.formData).subscribe(
      (res) => {
        console.log(res);
        this.router.navigateByUrl('/home');
        const Toast = Swal.mixin({
          toast: true,
          position: 'center',
          showConfirmButton: false,
          timer: 3000
        });
        Toast.fire({
          type: 'success',
          title: 'File upload successfully'
        });
      }, (err) => {
        console.log(err);
        console.log(err);
        const Toast = Swal.mixin({
          toast: true,
          position: 'center',
          showConfirmButton: false,
          timer: 3000
        });
        Toast.fire({
          type: 'error',
          title: 'Failed to upload file'
        });
      }
    );
  }

  // Update employee new password
  updatePassword() {
    console.log(this.userId);
    this.authSrv.updatePasswordById(this.userId, this.newEmp).subscribe(
      (res) => {
        console.log(res);
        this.router.navigateByUrl('/home');
        const Toast = Swal.mixin({
          toast: true,
          position: 'center',
          showConfirmButton: false,
          timer: 3000
        });
        Toast.fire({
          type: 'success',
          title: 'New Password Updated successfully'
        });
      }, (err) => {
        console.log(err);
        const Toast = Swal.mixin({
          toast: true,
          position: 'center',
          showConfirmButton: false,
          timer: 3000
        });
        Toast.fire({
          type: 'error',
          title: 'Failed to update new password'
        });
      }
    );
  }

  // Get Employee Profile
  employeeProfile() {
    this.authSrv.userOneById(this.userId).subscribe(
      (res) => { 
         this.employee = res;
         console.log("Employee Profile Info :", res);       
      },(err) => {
         console.log(err);
      }
    );
  }

  // Update employee profile
  updateEmployee() {
    console.log(this.userId);
    this.authSrv.userOneUpdateById(this.userId,this.newEmp).subscribe(
      (res) => {
        console.log(res);
        this.newEmp = res;
        this.router.navigateByUrl('/home');
        const Toast = Swal.mixin({
          toast: true,
          position: 'center',
          showConfirmButton: false,
          timer: 3000
        });
        Toast.fire({
          type: 'success',
          title: 'User details updated successfully!'
        });
      }, (err) => {
        console.log(err);
        const Toast = Swal.mixin({
          toast: true,
          position: 'center',
          showConfirmButton: false,
          timer: 3000
        });
        Toast.fire({
          type: 'error',
          title: 'Failed to update a User details?'
        });
      }
    );
  }
}