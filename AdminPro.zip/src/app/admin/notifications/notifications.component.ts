import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { AuthServicesService } from 'src/app/services/auth-service/auth-services.service';

@Component({
  selector: 'app-notifications',
  templateUrl: './notifications.component.html',
  styleUrls: ['./notifications.component.css']
})
export class NotificationsComponent implements OnInit {

  users;
  private userId: any;

  constructor(
    private authSrv: AuthServicesService,
    private route: ActivatedRoute
  ) { }

  ngOnInit() {
    this.usersList();
  }

  // usersList
  usersList() {
    this.authSrv.usersDetails().subscribe(
      (res) => {
        console.log(res);
        this.users = res;
      }, (err) => {
        console.log(err);
      }
    );
  }
}
