import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AuthServicesService } from 'src/app/services/auth-service/auth-services.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-settings',
  templateUrl: './settings.component.html',
  styleUrls: ['./settings.component.css']
})
export class SettingsComponent implements OnInit {

  userId = localStorage.getItem('userId');

  // File Upload
  formData = new FormData();
  @ViewChild("fileInput", {static: false}) fileInputRef:ElementRef;
  
  // Admin Profile Fields
  admin:Object = {
    profileImg: '',
    firstname: '',
    lastname: '',
    dob:'',
    designation: '',
    username: '',
    email: '',
    password: '',
    confirm_password: '',
    address:'',
    phoneNumber: ''
  };

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private authSrv: AuthServicesService
  ) {}

  ngOnInit() {
    console.log(this.userId);
  }

  onFileSelected(event){
    console.log(event.target.files[0]);
    this.formData.append('image', event.target.files[0]);
  }

  // Upload Image
  uploadImage() {
    console.log(this.formData.get('image'));
    this.authSrv.uploadProfileById(this.userId, this.formData).subscribe(
      (res) => {
        console.log(res);
        this.router.navigateByUrl('/home');
        const Toast = Swal.mixin({
          toast: true,
          position: 'center',
          showConfirmButton: false,
          timer: 3000
        });
        Toast.fire({
          type: 'success',
          title: 'File upload successfully'
        });
      }, (err) => {
        console.log(err);
        console.log(err);
        const Toast = Swal.mixin({
          toast: true,
          position: 'center',
          showConfirmButton: false,
          timer: 3000
        });
        Toast.fire({
          type: 'error',
          title: 'Failed to upload file'
        });
      }
    );
  }

  // Update user new password
  updatePassword() {
    console.log(this.userId);
    this.authSrv.updatePasswordById(this.userId, this.admin).subscribe(
      (res) => {
        console.log(res);
        this.router.navigateByUrl('/home');
        const Toast = Swal.mixin({
          toast: true,
          position: 'center',
          showConfirmButton: false,
          timer: 3000
        });
        Toast.fire({
          type: 'success',
          title: 'New Password Updated successfully'
        });
      }, (err) => {
        console.log(err);
        const Toast = Swal.mixin({
          toast: true,
          position: 'center',
          showConfirmButton: false,
          timer: 3000
        });
        Toast.fire({
          type: 'error',
          title: 'Failed to update new password'
        });
      }
    );
  }

  // Update Admin Profile Method
  updateAdmin() {
    console.log(this.userId);
    this.authSrv.userOneUpdateById(this.userId,this.admin).subscribe(
      (res) => {
        console.log(res);
        this.admin = res;
        this.router.navigateByUrl('/home');
        const Toast = Swal.mixin({
          toast: true,
          position: 'center',
          showConfirmButton: false,
          timer: 3000
        });
        Toast.fire({
          type: 'success',
          title: 'User details updated successfully'
        });
      }, (err) => {
        console.log(err);
        const Toast = Swal.mixin({
          toast: true,
          position: 'center',
          showConfirmButton: false,
          timer: 3000
        });
        Toast.fire({
          type: 'error',
          title: 'Failed to update a User details'
        });
      }
    );
  }
}