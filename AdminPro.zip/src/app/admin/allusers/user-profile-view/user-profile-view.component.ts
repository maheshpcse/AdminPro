import { Component, OnInit } from '@angular/core';
import { AuthServicesService } from 'src/app/services/auth-service/auth-services.service';
import { ActivatedRoute, Router } from '@angular/router';
import Swal from 'sweetalert2';
import * as $ from 'jquery';

@Component({
  selector: 'app-user-profile-view',
  templateUrl: './user-profile-view.component.html',
  styleUrls: ['./user-profile-view.component.css']
})
export class UserProfileViewComponent implements OnInit {

  private id: any;
  private username: any;

  user: Object = {
    profileImg: '',
    firstname: '',
    lastname: '',
    designation: '',
    email: '',
    username: '',
    phoneNumber: ''
  };

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private authSrv: AuthServicesService
  ) { }

  ngOnInit() {
    // Get User Details By Id
    this.route.params.subscribe(res => {
      console.log(res);
      this.id = res.userId;
      console.log(this.id);
    });
    this.authSrv.userOneById(this.id)
      .subscribe(
        res => {
          this.user = res;
          console.log('This is One User Data By Id', res);
        }
      );
    // Get User Details By Name
    // this.route.params.subscribe(res => {
    //   console.log(res);
    //   this.username = res.userName;
    //   console.log(this.username);
    // });
    // this.authSrv.userOneByName(this.username)
    //   .subscribe(
    //     res => {
    //       this.user = res;
    //       console.log('This is One User Data By Name', res);
    //     }
    //   );

    $('#exampleModal').on('show.bs.modal', function (event) {
      var button = $(event.relatedTarget) // Button that triggered the modal
      var recipient = button.data('whatever') // Extract info from data-* attributes
      // If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
      // Update the modal's content. We'll use jQuery here, but you could use a data binding library or other methods instead.
      var modal = $(this)
      modal.find('.modal-title').text('New message to ' + recipient)
      modal.find('.modal-body input').val(recipient)
    })
  }
}
