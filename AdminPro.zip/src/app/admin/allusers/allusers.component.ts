import { Component, OnInit } from '@angular/core';
import { AuthServicesService } from 'src/app/services/auth-service/auth-services.service';
import Swal from 'sweetalert2';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-allusers',
  templateUrl: './allusers.component.html',
  styleUrls: ['./allusers.component.css']
})
export class AllusersComponent implements OnInit {

  users;
  private userId: any;

  constructor(
    private authSrv: AuthServicesService,
    private route: ActivatedRoute
  ) { }

  ngOnInit() {
   this.usersList();
  }

  // usersList
  usersList() {
    this.authSrv.usersDetails().subscribe(
      (res) => {
        console.log(res);
        this.users = res;
      }, (err) => {
        console.log(err);
      }
    );
  }

  // Detele one user method
  deleteUserone(userId) {
    this.route.params.subscribe(
      (res) => {
        console.log(res);
        this.userId = res.userId;
        // console.log(this.userId);
      }
    );
    this.authSrv.userOneDeleteById(userId).subscribe(
      (res) => {
        console.log(res);
        res = this.users;
        const Toast = Swal.mixin({
          toast: true,
          position: 'center',
          showConfirmButton: false,
          timer: 3000
        });
        Toast.fire({
          type: 'success',
          title: 'Delete success!'
        });
      }, (err) => {
        console.log(err);
        const Toast = Swal.mixin({
          toast: true,
          position: 'center',
          showConfirmButton: false,
          timer: 3000
        });
        Toast.fire({
          type: 'error',
          title: 'Delete failed?'
        });
      }
    );
    this.usersList();
  }
}
