'use strict';


customElements.define('compodoc-menu', class extends HTMLElement {
    constructor() {
        super();
        this.isNormalMode = this.getAttribute('mode') === 'normal';
    }

    connectedCallback() {
        this.render(this.isNormalMode);
    }

    render(isNormalMode) {
        let tp = lithtml.html(`
        <nav>
            <ul class="list">
                <li class="title">
                    <a href="index.html" data-type="index-link">admin-pro documentation</a>
                </li>

                <li class="divider"></li>
                ${ isNormalMode ? `<div id="book-search-input" role="search"><input type="text" placeholder="Type to search"></div>` : '' }
                <li class="chapter">
                    <a data-type="chapter-link" href="index.html"><span class="icon ion-ios-home"></span>Getting started</a>
                    <ul class="links">
                        <li class="link">
                            <a href="overview.html" data-type="chapter-link">
                                <span class="icon ion-ios-keypad"></span>Overview
                            </a>
                        </li>
                        <li class="link">
                            <a href="index.html" data-type="chapter-link">
                                <span class="icon ion-ios-paper"></span>README
                            </a>
                        </li>
                        <li class="link">
                            <a href="dependencies.html" data-type="chapter-link">
                                <span class="icon ion-ios-list"></span>Dependencies
                            </a>
                        </li>
                    </ul>
                </li>
                    <li class="chapter modules">
                        <a data-type="chapter-link" href="modules.html">
                            <div class="menu-toggler linked" data-toggle="collapse" ${ isNormalMode ?
                                'data-target="#modules-links"' : 'data-target="#xs-modules-links"' }>
                                <span class="icon ion-ios-archive"></span>
                                <span class="link-name">Modules</span>
                                <span class="icon ion-ios-arrow-down"></span>
                            </div>
                        </a>
                        <ul class="links collapse" ${ isNormalMode ? 'id="modules-links"' : 'id="xs-modules-links"' }>
                            <li class="link">
                                <a href="modules/AppModule.html" data-type="entity-link">AppModule</a>
                                    <li class="chapter inner">
                                        <div class="simple menu-toggler" data-toggle="collapse" ${ isNormalMode ?
                                            'data-target="#components-links-module-AppModule-f1d28796523abf453d4db09a3cd2d6f8"' : 'data-target="#xs-components-links-module-AppModule-f1d28796523abf453d4db09a3cd2d6f8"' }>
                                            <span class="icon ion-md-cog"></span>
                                            <span>Components</span>
                                            <span class="icon ion-ios-arrow-down"></span>
                                        </div>
                                        <ul class="links collapse" ${ isNormalMode ? 'id="components-links-module-AppModule-f1d28796523abf453d4db09a3cd2d6f8"' :
                                            'id="xs-components-links-module-AppModule-f1d28796523abf453d4db09a3cd2d6f8"' }>
                                            <li class="link">
                                                <a href="components/AboutComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">AboutComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/AllusersComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">AllusersComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/AngularComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">AngularComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/AppComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">AppComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/BootstrapComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">BootstrapComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/ContactComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">ContactComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/CssComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">CssComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/DatabaseComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">DatabaseComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/EmployeesComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">EmployeesComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/ExpressComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">ExpressComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/FaqComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">FaqComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/FilmsComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">FilmsComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/FooterComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">FooterComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/FullstackComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">FullstackComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/HeaderNavComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">HeaderNavComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/HomePageComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">HomePageComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/HtmlComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">HtmlComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/JavascriptComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">JavascriptComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/LoginComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">LoginComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/MongodbComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">MongodbComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/NodejsComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">NodejsComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/NotFoundComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">NotFoundComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/NotificationsComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">NotificationsComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/ProfileComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">ProfileComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/SettingsComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">SettingsComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/SignupComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">SignupComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/UserProfileViewComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">UserProfileViewComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/ViewFilmComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">ViewFilmComponent</a>
                                            </li>
                                            <li class="link">
                                                <a href="components/ViewProfileComponent.html"
                                                    data-type="entity-link" data-context="sub-entity" data-context-id="modules">ViewProfileComponent</a>
                                            </li>
                                        </ul>
                                    </li>
                                <li class="chapter inner">
                                    <div class="simple menu-toggler" data-toggle="collapse" ${ isNormalMode ?
                                        'data-target="#injectables-links-module-AppModule-f1d28796523abf453d4db09a3cd2d6f8"' : 'data-target="#xs-injectables-links-module-AppModule-f1d28796523abf453d4db09a3cd2d6f8"' }>
                                        <span class="icon ion-md-arrow-round-down"></span>
                                        <span>Injectables</span>
                                        <span class="icon ion-ios-arrow-down"></span>
                                    </div>
                                    <ul class="links collapse" ${ isNormalMode ? 'id="injectables-links-module-AppModule-f1d28796523abf453d4db09a3cd2d6f8"' :
                                        'id="xs-injectables-links-module-AppModule-f1d28796523abf453d4db09a3cd2d6f8"' }>
                                        <li class="link">
                                            <a href="injectables/AuthGuardService.html"
                                                data-type="entity-link" data-context="sub-entity" data-context-id="modules" }>AuthGuardService</a>
                                        </li>
                                        <li class="link">
                                            <a href="injectables/AuthServicesService.html"
                                                data-type="entity-link" data-context="sub-entity" data-context-id="modules" }>AuthServicesService</a>
                                        </li>
                                        <li class="link">
                                            <a href="injectables/FilmsServicesService.html"
                                                data-type="entity-link" data-context="sub-entity" data-context-id="modules" }>FilmsServicesService</a>
                                        </li>
                                        <li class="link">
                                            <a href="injectables/TokenInterceptorService.html"
                                                data-type="entity-link" data-context="sub-entity" data-context-id="modules" }>TokenInterceptorService</a>
                                        </li>
                                    </ul>
                                </li>
                            </li>
                            <li class="link">
                                <a href="modules/AppRoutingModule.html" data-type="entity-link">AppRoutingModule</a>
                            </li>
                </ul>
                </li>
                    <li class="chapter">
                        <div class="simple menu-toggler" data-toggle="collapse" ${ isNormalMode ? 'data-target="#classes-links"' :
                            'data-target="#xs-classes-links"' }>
                            <span class="icon ion-ios-paper"></span>
                            <span>Classes</span>
                            <span class="icon ion-ios-arrow-down"></span>
                        </div>
                        <ul class="links collapse" ${ isNormalMode ? 'id="classes-links"' : 'id="xs-classes-links"' }>
                            <li class="link">
                                <a href="classes/Reviews.html" data-type="entity-link">Reviews</a>
                            </li>
                        </ul>
                    </li>
                        <li class="chapter">
                            <div class="simple menu-toggler" data-toggle="collapse" ${ isNormalMode ? 'data-target="#injectables-links"' :
                                'data-target="#xs-injectables-links"' }>
                                <span class="icon ion-md-arrow-round-down"></span>
                                <span>Injectables</span>
                                <span class="icon ion-ios-arrow-down"></span>
                            </div>
                            <ul class="links collapse" ${ isNormalMode ? 'id="injectables-links"' : 'id="xs-injectables-links"' }>
                                <li class="link">
                                    <a href="injectables/AuthGuardService.html" data-type="entity-link">AuthGuardService</a>
                                </li>
                                <li class="link">
                                    <a href="injectables/AuthServicesService.html" data-type="entity-link">AuthServicesService</a>
                                </li>
                                <li class="link">
                                    <a href="injectables/CharServicesService.html" data-type="entity-link">CharServicesService</a>
                                </li>
                                <li class="link">
                                    <a href="injectables/EmployeeServicesService.html" data-type="entity-link">EmployeeServicesService</a>
                                </li>
                                <li class="link">
                                    <a href="injectables/FilmsServicesService.html" data-type="entity-link">FilmsServicesService</a>
                                </li>
                                <li class="link">
                                    <a href="injectables/TokenInterceptorService.html" data-type="entity-link">TokenInterceptorService</a>
                                </li>
                            </ul>
                        </li>
                    <li class="chapter">
                        <div class="simple menu-toggler" data-toggle="collapse" ${ isNormalMode ? 'data-target="#miscellaneous-links"'
                            : 'data-target="#xs-miscellaneous-links"' }>
                            <span class="icon ion-ios-cube"></span>
                            <span>Miscellaneous</span>
                            <span class="icon ion-ios-arrow-down"></span>
                        </div>
                        <ul class="links collapse" ${ isNormalMode ? 'id="miscellaneous-links"' : 'id="xs-miscellaneous-links"' }>
                            <li class="link">
                                <a href="miscellaneous/variables.html" data-type="entity-link">Variables</a>
                            </li>
                        </ul>
                    </li>
                        <li class="chapter">
                            <a data-type="chapter-link" href="routes.html"><span class="icon ion-ios-git-branch"></span>Routes</a>
                        </li>
                    <li class="chapter">
                        <a data-type="chapter-link" href="coverage.html"><span class="icon ion-ios-stats"></span>Documentation coverage</a>
                    </li>
                    <li class="divider"></li>
                    <li class="copyright">
                        Documentation generated using <a href="https://compodoc.app/" target="_blank">
                            <img data-src="images/compodoc-vectorise.png" class="img-responsive" data-type="compodoc-logo">
                        </a>
                    </li>
            </ul>
        </nav>
        `);
        this.innerHTML = tp.strings;
    }
});