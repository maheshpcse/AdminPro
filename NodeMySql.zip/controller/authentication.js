var mysql = require('mysql');

// Create connection
var connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'User'
});

// Database connection
connection.connect(function (err) {
    if (err) throw err;
    console.log('Connected to User Database!');
});


// User Registraion
module.exports.userRegistration = function (req, res, next) {
    // var today = new Date();
    var data = {
        "username": req.body.username,
        "email": req.body.email,
        "password": req.body.password,
        "phonenumber": req.body.phonenumber,
    }
    var query = `INSERT INTO users VALUES SET ?`;
    connection.query(query,data, function (err, results, fields) {
        if (err) {
            console.log('Error in user registration', err);
            res.status(500).send(err);
        } else {
            console.log('User registration successfull:', results);
            res.status(200).json(result);
        }
        connection.end();
    });
}

// User Login
module.exports.userLogin = function (req, res, next) {
    var username = req.body.username;
    var password = req.body.password;
    var query = `'SELECT * FROM users WHERE username = ?'`;
    connection.query(query, [username], function (error, results, fields) {
        if (error) {
            console.log("error ocurred", error);
            res.send({
                "code": 400,
                "failed": "error ocurred"
            })
        } else {
            console.log('The solution is:', results);
            if (results.length > 0) {
                if (results[0].password == password) {
                    res.send({
                        "code": 200,
                        "success": "User login sucessfull"
                    });
                } else {
                    res.send({
                        "code": 204,
                        "success": "Username and password does not match"
                    });
                }
            } else {
                res.send({
                    "code": 204,
                    "success": "Username does not exits"
                });
            }
        }
    });
}