var mysql = require('mysql');

// Create connection
var connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'Employee'
});

// Database connection
connection.connect(function (err) {
    if (err) throw err;
    console.log('Connected to Employee Database!');
});


// Add employees data
module.exports.addEmployees = function (req, res, next) {
    var today = new Date();
    const data = {
        "name": req.body.name,
        "position": req.body.position,
        "salary": req.body.salary,
        "createdAt": today
    }
    var query = `INSERT INTO employees SET ?`;
    connection.query(query, data, function (err, results) {
        if (err) {
            console.log('Error in inserting values', err);
            res.status(500).send(err);
        } else {
            console.log('Employee values inserted:', results);
            res.status(200).json(results);
        }
    });
}

// Get Employees data
module.exports.getEmployees = function (req, res, next) {
    var query = `SELECT * FROM employees`;
    connection.query(query, function(err, results) {
        if (err) {
            console.log('Error in getting values', err);
            res.status(500).send(err);
        } else {
            console.log('Getting employees details:', results);
            res.status(200).json(results);
        }
    });
}