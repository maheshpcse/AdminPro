const host = '127.0.0.1';
const port = 3000;
// const dbUrl = 'mongodb://rootUser:password1@ds121406.mlab.com:21406/myform';
const dbUrl = 'mongodb://MaheshCse:maheshcse1599@ds253094.mlab.com:53094/myhotel';
// const authSource = 'admin';
const DbUser = 'rootUser';
const DbPasswd = 'password';
const secreatKey = 'MaheshPro';

module.exports = {
  HOST:host,
  PORT:port,
  DBURL:dbUrl,
  // AUTHSRC:authSource,
  // DBUSR:DbUser,
  // DBPASSWD:DbPasswd,
  SECREATKEY:secreatKey
}