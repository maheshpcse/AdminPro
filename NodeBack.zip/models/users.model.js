const mongoose = require('mongoose');

//User Schema
const userSchema = mongoose.Schema({
  profileImg:{
    type: String
  },
  firstname: {
    type: String,
    required: true
  },
  lastname: {
    type: String,
    required: true
  },
  dob: {
    type: Date,
    required: true
  },
  designation: {
    type: String,
    required: true
  },
  username: {
    type: String,
    required: true,
    // unique: true
  },
  email: {
    type: String,
    required: true,
    unique: true
  },
  password: String,
  confirm_password: String,
  address: {
    type: String,
    required: true
  },
  role: {
    type: String,
    required: true,
    "default": 'user'
  },
  phoneNumber: Number,
  // gender: {
  //   type: String,
  //   "default": "Male"
  // },
  regDate: {
    type: Date,
    "default": Date.now
  },
  lastLoginDate: {
    type: Date,
    "default": Date.now
  },
  isActive: {
    type: Boolean,
    "default": false
  }
});

mongoose.model('User', userSchema, 'users');