const mongoose = require('mongoose');

var studentSchema = mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    email: {
        type: String,
        required: true
    },
    img: {
        type: String
    }
});

mongoose.model('Student', studentSchema, 'students');