const mongoose = require('mongoose');
var charactersSchema = require('./characters.model');

// Films Schema
const flimSchema = mongoose.Schema({
    title: {
        type: String,
    },
    episode_id: {
        type: Number,
    },
    opening_crawl: {
        type: String
    },
    director: {
        type: String
    },
    producer: {
        type: String
    },
    release_date: {
        type: String
    },
    characters: [charactersSchema],
    planets: [String],
    starships: [String],
    vehicles: [String],
    species: [String],
    created: {
        type: String,
    },
    edited: {
        type: String
    },
    url: {
        type: String
    }
});

mongoose.model('Film', flimSchema, 'films');