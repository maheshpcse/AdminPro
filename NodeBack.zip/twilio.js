var accountSid = 'AC8ffa8478ebd9502da3468d684f5409f7';
var authToken = '293fd534ecd83af21e8a3bef7886b84f';

var twilio = require('twilio');
var client = new twilio(accountSid, authToken);

client.messages.create({
    body: 'Hello from Node',
    to: '+918886197968',
    from: '+12028049209'
})
.then((message) => console.log(message.sid));