var express = require('express');
var router = express.Router();
const hotelCtrl = require('../controllers/hotels.controller');
const authCtrl = require('../controllers/auth.controller');

router
.route('/allhotels')
.get(hotelCtrl.getAllHotels); // Get All Hotels Data

router
.route('/hotels')
// .get(authCtrl.validateToken,hotelCtrl.getHotelsData); // Get Hotels Data By Filter
.get(hotelCtrl.getHotelsData);

router
.route('/hotels/new')
.post(authCtrl.validateToken,hotelCtrl.addHotelNew); // Add New Hotel Data

router
.route('/hotels/id/:hotelId')
.get(hotelCtrl.getHotelDataById); // Get One Hotel Data with HotelId

router
.route('/hotels/name/:hotelName')
.get(hotelCtrl.getHotelDataByName); // Get One Hotel Data with HotelName

router
.route('/hotels/:hotelId/reviews')
.get(hotelCtrl.getHotelReviews) // Get Hotel Reviews
.put(hotelCtrl.addHotelReview); // Add Hotel Review

router
.route('/hotels/:hotelId/reviews/:reviewId')
.get(hotelCtrl.getHotelOneReview); // Get Hotel One Review with HotelId

module.exports = router;
