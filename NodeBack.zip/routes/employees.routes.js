var express = require('express');
var router = express.Router();

const empCtrl = require('../controllers/employee.controller');

router
.route('/save')
.post(empCtrl.saveEmployeeData) // Save Employee Data

router
.route('/emps')
.get(empCtrl.getAllEmployees) // Get Employee Data

router
.route('/emps/delete/:empId')
.get(empCtrl.deleteOneEmp) // Delete One Employee Data

router
.route('/student')
.post(empCtrl.saveStudData)

module.exports = router;