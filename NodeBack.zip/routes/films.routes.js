var express = require('express');
var router = express.Router();

const filmCtrl = require('../controllers/films.controller');

router
.route('/allfilms')
.get(filmCtrl.getAllFilms) // Get All Films Data

router
.route('/allfilms/film/:filmId')
.get(filmCtrl.getOneFilmById) // Get One Film Data By Id

module.exports = router;