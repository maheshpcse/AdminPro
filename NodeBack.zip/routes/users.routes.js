var express = require('express');
var router = express.Router();
const userCtrl = require('../controllers/users.controller');
const authCtrl = require('../controllers/auth.controller');

router
.route('/allusers')
.get(userCtrl.getAllUsers) // Get All Users List

router
.route('/allusers/id/:userId')
.get(userCtrl.getOneUserById) // Get One User Details By Id

router
.route('/allusers/username/:userName')
.get(userCtrl.getOneUserByfirstname) // Get One User Details By Name

router
.route('/allusers/update/:userId')
.post(userCtrl.updateOneUser) // Update Profile For User By Id

router
.route('/allusers/password/:userId')
.post(userCtrl.updatePassword) // Update Password For User By Id

router
.route('/allusers/delete/:userId')
.get(userCtrl.deleteOneUser) // Delete One User By Id

router
.route('/allusers/file/:userId')
.post(userCtrl.fileUploader) // Upload Image for User By Id

// router
// .route('/user')
// .get(userCtrl.getUser)
// .post(userCtrl.addUser)
// .put(userCtrl.updateUser)

// router
// .route('/users')
// .get(userCtrl.getUsers)

router
.route('/register')
.post(authCtrl.registration)

router
.route('/login')
.post(authCtrl.login)

router
.route('/token')
.get(authCtrl.validateToken)

router
.route('/addreview')
.post(userCtrl.addReviews) // Add Reviews

router
.route('/delete/:reviewId') 
.delete(userCtrl.deleteReviews) // Delete Reviews

router
.route('/allreviews')
.get(userCtrl.getAllReviews) // Get All Reviews

module.exports = router;
