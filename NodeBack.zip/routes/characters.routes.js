var express = require('express');
var router = express.Router();

const charCtrl = require('../controllers/characters.controller');

router
.route('/allactors')
.get(charCtrl.getAllCharacters) // Get All Characeters

router
.route('/allactors/id/:charId') 
.get(charCtrl.getOneCharacterById) // Get One Character By Id

module.exports = router;