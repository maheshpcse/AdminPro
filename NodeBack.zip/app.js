var express = require('express');
var app = express();
var path = require('path');
var bodyParser = require('body-parser');

const host = '127.0.0.1';
const port = 3000;

app.use(express.static(path.join(__dirname, 'public')));

app.use(function(req, res, next){
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Credentials", "true");
    res.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, PATCH, OPTIONS");
    res.header("Access-COntrol-Allow-Headers", "Origin, Authorization, X-Requested-With, Content-Type, x-access-token, Content-Length, Accept");
    next();
});

app.use(bodyParser.urlencoded({
    extended: false
}));

app.use(bodyParser.json());

app.get('/', function(req, res){
    res.send("A Simple Node.js Server is Running");
    res.end(); 
});

app.listen(port, function(req, res){
    console.log(`Express server is running on port ${port}`);
});