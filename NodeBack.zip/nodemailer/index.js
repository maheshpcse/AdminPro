const nodemailer = require('nodemailer');
const xoauth2 = require('xoauth2');

const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        type: 'OAuth2',
        user: 'maheshmahi1599@gmail.com',
        clientId: '870802741227-brp96li79avcsjnj29klpoflokub1nha.apps.googleusercontent.com',
        clientSecret: 'ewv5cNurI7PqzIFapvnFgr1k',
        refreshToken: '1/etZoQwstT0zrF06c2PSjdhAabBw8f7r97rHKq_UcGDc',
        accessToken: 'ya29.GlvYBucrosV_HgvolaYUqww8O_BAcuD8QmXAd-92xbV6_JTPGV9KNP9vUP_D2GAV6gKhghNtbAaSTq1HMmvVIMqKjk4c1xIkkpJDcopn4nWowpnete-hSbKaOpH6',
    },
});

var mailOptions = {
    from: 'Mahesh <maheshmahi1599@gmail.com>',
    to: 'samsarella7777@gmail.com',
    subject: 'Testing Nodemailer',
    text: 'Hi Sam Bro, This is Mahesh from VisualPath'
}

transporter.sendMail(mailOptions, function (err, res) {
    if (err) {
        console.log('Error');
    } else {
        console.log('Email Sent Success');
    }
});