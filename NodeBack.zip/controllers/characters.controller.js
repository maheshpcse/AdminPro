var mongoose = require('mongoose');
var Character = mongoose.model('Character');

// Get All Characters Data
module.exports.getAllCharacters = function (req, res, next) {
    Character
        .find({})
        .exec(function (err, characters) {
            if (err) {
                console.log(err);
                res.status(500)
                    .json({
                        error: err,
                        message: 'Unable to get characters data'
                    });
            } else {
                console.log('Found films data', characters.length);
                res.status(200)
                    .json(characters);
            }
        });
}

// Get One Character Data By Id
module.exports.getOneCharacterById = function (req, res, next) {
    var charId = req.params.charId;
    console.log(charId);
    // console.log(req.params);
    Character
        .findById(charId, function(err, character) {
            if(err) {
                console.log(err);
            } else {
                res.status(200)
                    .json(character);
            }
        });
}