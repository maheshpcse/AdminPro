var mongoose = require('mongoose');
var User = mongoose.model('User');
var Review = mongoose.model('Review');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

//require multer for the file uploads
var multer = require('multer');
// set the directory for the uploads to the uploaded to
var DIR = './uploads/';

var http = require('http');
var fs = require('fs');
var url = require('url');

//define the type of upload multer would be doing and pass in its destination
var upload = multer({
  dest: DIR
}).single('image');

// File upload method
module.exports.fileUploader = (req, res, next) => {
  var userId = req.params.userId;
  // console.log(userId);
  var path = '';
  upload(req, res, function (err) {
    if (err) {
      console.log(err); // An error occurred when uploading
      return res.status(422).send("an Error occured")
    }
    //console.log(req.file) //for complete file data
    path = req.file.path;
    console.log(req.file);
    User.findById(userId, function (error, user) {
      if (error) console.log(error);
      if (user.profileImg) {
        deletePath = user.profileImg.substr(22);
        // console.log("previous:" + deletePath);
        if (fs.existsSync(deletePath)) {
          fs.unlinkSync(deletePath);
          user.profileImg = "http://localhost:3000/" + path;
          user.save(function (err, user) {
            if (err) return handleError(err);
            res.send(user);
          });
        } else {
          console.log("File Does not Exit");
          user.profileImg = "http://localhost:3000/" + path;
          user.save(function (err, user) {
            if (err) return handleError(err);
            res.send(user);
          });
        }
      } else {
        console.log("File Does not Exit");
        user.profileImg = "http://localhost:3000/" + path;
        user.save(function (err, user) {
          if (err) return handleError(err);
          res.send(user);
        });
      }
    })
  });
}

// Add Review
module.exports.addReviews = function (req, res, next) {
  if (!req.body || !req.body.name || !req.body.email || !req.body.review || !req.body.rating) {
    res.status(422).json({
      message: "Failed to Add Reviews, Required Fields are Missing"
    });
  } else {
    var newReview = new Review({
      name: req.body.name,
      email: req.body.email,
      review: req.body.review,
      rating: req.body.rating
    });
    newReview.save(function (err, review) {
      if (err) {
        res.status(500).json({
          payLoad: {
            error: err,
            messsage: "Failed to Add Review"
          }
        });
      } else {
        res.status(200).json({
          payLoad: {
            message: "Review Added SuccessFully!",
          }
        });
      }
    });
  }
}

// Delete reviews
module.exports.deleteReviews = function(req, res, next) {
  var reviewId = req.params.reviewId;
  Review
    .findByIdAndRemove(reviewId, (err, review)=> {
      if (err) {
        console.log("error", err);
      } else {
        console.log('Review deleted, id: ', reviewId);
        res.status(201)
            .json({"msg":"review id is deleted successfully....!!!"});
      }
    });
}

// Get all reviews
module.exports.getAllReviews = function (req, res, next) {
  Review
    .find({})
    .exec(function (err, reviews) {
      if (err) {
        console.log(err);
        res.status(500)
          .json({
            error: err,
            message: 'Unable to get reviews'
          });
      } else {
        console.log('Found reviews', reviews.length);
        res.status(200)
          .json(reviews);
      }
    });
}

// Get all users list
module.exports.getAllUsers = function (req, res, next) {
  User
    .find({})
    .exec(function (err, users) {
      if (err) {
        console.log(err);
        res.status(500)
          .json({
            error: err,
            message: 'Unable to get users list'
          });
      } else {
        console.log('Found users', users.length);
        res.status(200)
          .json(users);
      }
    });
}

// Get One User By Id
// module.exports.getOneUserById = function (req, res, next) {
//   var userId = req.params.userId;
//   console.log(userId);
//   if (userId) {
//     User
//       .findById(userId)
//       .exec(function (err, user) {
//         res.status(200)
//           .json(user)
//       });
//   } else {
//     res.status(404).json({
//       message: 'User Id not found'
//     });
//   }
// }
module.exports.getOneUserById = function (req, res, next) {
  var userId = req.params.userId;
  console.log(userId);
  User
    .findById(userId, (err, user) => {
      if (err) {
        console.log(err);
      }
      res.status(200).json(user);
    });
}

// Get One User By firstname
module.exports.getOneUserByfirstname = function (req, res, next) {
  var userfirstname = req.params.userfirstname;
  console.log(userfirstname);
  if (userfirstname) {
    console.log(userfirstname);
    User.
    find({
        userfirstname: userfirstname
      })
      .exec(function (err, user) {
        if (err) {
          console.log(err);
          res.status(404).send(err).json({
            message: "User firstname is incorrect"
          });
        } else {
          console.log(user.length);
          res.status(200).send(user);
        }
      });
  } else {
    res.status(404)
      .json({
        message: "User firstname Not Found"
      });
  }
}

// Update One User
module.exports.updateOneUser = function (req, res, next) {
  var userId = req.params.userId;
  console.log("Get userId", userId);

  User
    .findById(userId)
    .exec(function (err, user) {
      var response = {
        status: 200,
        message: user
      };
      if (err) {
        console.log('Error finding user');
        response.status = 500;
        response.message = err;
      } else if (!user) {
        response.status = 404;
        response.message = {
          "message": 'User ID not found'
        }
      } else if (response.status == 200) {
        user.firstname = req.body.firstname;
        user.lastname = req.body.lastname;
        user.dob = req.body.dob;
        user.designation = req.body.designation;
        user.username = req.body.username;
        user.email = req.body.email;
        user.address = req.body.address;
        user.phoneNumber = req.body.phoneNumber;
      }
      user.save(function (err, userUpdated) {
        if (err) {
          res
            .status(500)
            .json(err);
        } else {
          res
            .status(204)
            .json({
              message: 'User Details Successfully Updated'
            });
        }
      });
    });
}

// Update User Password
module.exports.updatePassword = function (req, res, next) {
  var userId = req.params.userId;
  console.log("Get User Id :", userId);

  User
    .findById(userId)
    .exec(function (err, user) {
      if (err) {
        console.log("Error finding user Id");
        res.status(500).send(err);
      } else if (!user) {
        console.log("User Id Not Found");
        res.status(404).json({
          message: 'User Id Not Found'
        });
      } else if (user) {
        const saltRounds = 10;
        var salt = bcrypt.genSaltSync(saltRounds);
        var hashPassword = bcrypt.hashSync(req.body.password, salt);
        var hashConfirm_password = bcrypt.hashSync(req.body.confirm_password, salt);
        user.password = hashPassword;
        user.confirm_password = hashConfirm_password;
        if (hashPassword == hashConfirm_password) {
          // res.status(200).json({
          //   message: 'New Password Updated Successfully'
          // });
        }
      }
      user.save(function (err, userUpdated) {
        if (err) {
          res
            .status(500)
            .json(err);
        } else {
          res
            .status(200)
            .json({
              message: 'User New Password Updated Successfully'
            });
        }
      });
    });
}

// Delete One User
module.exports.deleteOneUser = function (req, res, next) {
  var userId = req.params.userId;
  User
    .findByIdAndRemove(userId)
    .exec(function (err, user) {
      if (err) {
        res.status(404).json(err)
      } else {
        console.log('User deleted, id: ', userId);
        res.status(200).json({
          message: 'User deleted Successfully'
        });
      }
    });
}

// CRUD Operations
// module.exports.getUser = function (req, res) {
//   var user = {
//     firstname: "John Smith",
//     age: 29
//   }
//   res
//     .status(200)
//     .json(user)
// }

// module.exports.getUsers = function (req, res) {
//   var users = [{
//       firstname: "John Smith",
//       age: 29
//     },
//     {
//       firstname: "Rogn Smith",
//       age: 20
//     },
//     {
//       firstname: "Wikky Smith",
//       age: 21
//     }
//   ];
//   res
//     .status(200)
//     .json(users)
// }

// module.exports.addUser = (req, res) => {
//   res
//     .status(200)
//     .json({
//       message: 'This is a post request'
//     });
// }

// module.exports.updateUser = (req, res) => {
//   res
//     .status(200)
//     .json({
//       message: 'This is a put request'
//     });
// }