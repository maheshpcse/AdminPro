var mongoose = require('mongoose');
var Employee = mongoose.model('Employee');
var Student = mongoose.model('Student');
var multer = require('multer');
var fs = require('fs');
var path = require('path');

// SET PATH
var DIR = './uploads/';

// SET STORAGE
var storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'uploads');
    },
    filename: function (req, file, cb) {
        cb(null, file.fieldname + '-' + Date.now());
    }
});

// SET DESTINATION
var upload = multer({
    dest: DIR,
    storage: storage
}).single('profileImg');

var upload1 = multer({
    dest: DIR,
    storage: storage
}).single('img');

// Save The Employee Data
module.exports.saveEmployeeData = function (req, res, next) {
    // console.log("main req is",req);
    // if (!req.body || !req.body.name || !req.body.email || !req.body.phoneNum || !req.body.profileImg) {
    //     res.status(404).json({
    //         message: "Failed To Save Employee Data"
    //     });
    // } else {
        upload(req, res, function(err) {
            if (!req.file) {
                console.log("No file received");
                return res.send({
                    success: false
                });
            } else {
                console.log('file received', req);
                console.log(req.file);
                var Image = "http://localhost:3000/" + req.file.path;
                console.log(Image);

                var newEmp = new Employee({
                    name: req.body.name,
                    email: req.body.email,
                    phoneNum: req.body.phoneNum,
                    profileImg: Image
                });
                newEmp
                    .save(function (err, result) {
                        if (err) {
                            console.log("Data not saved", err);
                            res.status(500).json(err)
                        } else {
                            console.log("Data saved successfully", result);
                            res.status(200).json(result);
                        }
                    });
            }
        });
    // }
}

// Get All Employee Data
module.exports.getAllEmployees = function (req, res, next) {
    Employee
        .find({})
        .exec(function (err, employees) {
            if (err) {
                console.log(err);
                res.status(500)
                    .json({
                        error: err,
                        message: 'Unable to get employees data'
                    });
            } else {
                console.log('Found employees data', employees.length);
                res.status(200)
                    .json(employees);
            }
        });
}

// Delete One Employee Data
module.exports.deleteOneEmp = function (req, res, next) {
    var empId = req.params.empId;
    Employee
        .findByIdAndRemove(empId)
        .exec(function (err, employee) {
            if (err) {
                res.status(404).json(err)
            } else {
                console.log('Employee data deleted, Id: ', empId);
                res.status(200).json({
                    message: 'Employee data deleted Successfully'
                });
            }
        });
}

module.exports.saveStudData = function (req, res, next) {
    // console.log(req.file);
    upload1(req, res, function(err, data) {
        if(!req.file) {
            console.log('No file received');
            return res.status(422).send({
                success: false
            });
        } else {
            console.log('File received', req);
            console.log(req.file);            
            var Image = 'http://localhost:3000/' + req.file.path;

            var student = new Student({
                name: req.body.name,
                email: req.body.email,
                img: Image
            });

            student
                .save((err, result)=> {
                    if(err) console.log(err);
                    console.log('Saved data succues', result);
                    return res.status(200).send({
                        success: true
                    });
                });
        }
    });
}