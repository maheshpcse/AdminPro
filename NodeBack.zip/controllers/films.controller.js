var mongoose = require('mongoose');
var Film = mongoose.model('Film');

// Get All Films Data
module.exports.getAllFilms = function (req, res, next) {
    Film
        .find({})
        .exec(function (err, films) {
            if (err) {
                console.log(err);
                res.status(500)
                    .json({
                        error: err,
                        message: 'Unable to get films data'
                    });
            } else {
                console.log('Found films data', films.length);
                res.status(200)
                    .json(films);
            }
        });
}

// Get One Film Data By Id
module.exports.getOneFilmById = function (req, res, next) {
    var filmId = req.params.filmId;
    console.log(filmId);
    console.log(req.params);
    Film
        .findById(filmId, function(err, film) {
            if(err) {
                console.log(err);
            } else {
                res.status(200)
                    .json(film);
            }
        });
}