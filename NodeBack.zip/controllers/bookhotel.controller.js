var mongoose = require('mongoose');
var Hotel = mongoose.model('Hotel');

module.exports.bookMyHotel = (req,res,next)=>{
    //Book one hotel
    console.log('Book one hotel');
    if(req.body && req.body.name){
        var hotel = new Hotel(req.body);
        hotel.save(function(err,res){
            if(err){
                res.status(500)
                .json({
                    message:'Hotel booking is failed'
                });
            } else{
                console.log('Hotel booking is success');
                res.status(200)
                .json(res);
            }
        })
    } else{
        console.log('Hotel name is not found');
        res.status(404)
        .json({
            message:'Hotel name is not found'
        });
    }
}