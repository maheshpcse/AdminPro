import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../services/employee.service';
import { IEmployee } from '../interfaces/iemployee';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  employees: IEmployee[] = [];
  loading: boolean;

  employeeForm: FormGroup;
  loader: boolean;

  constructor(
    private _employeeService: EmployeeService,
    private _fb: FormBuilder,
  ) { }

  ngOnInit() {
    this.loading = true;
    this.getEmployee();

    this.employeeForm = this._fb.group({
      name: ['', Validators.required],
      position: ['Manager', Validators.required],
      salary: ['', Validators.required]
    });
  }


  getEmployee() {
    this._employeeService.getEmpList().subscribe(data=>{
        this.employees = data;
        console.log("1111111111",this.employees);
        this.loading = false;
      }
    )
  }

  onSubmit() {
    const param = this.employeeForm.value;
    this._employeeService.addEmpToList(param).subscribe(
      (employee: IEmployee) => {
        this.loader = false;
        this.employeeForm.reset({position: 'Manager'});
        Swal.fire({
          position: 'top-end',
          type: 'success',
          title: 'Your work has been saved',
          showConfirmButton: false,
          timer: 1500
        });
        this.getEmployee();
      },(error) => {
        console.error(error);
        this.loader = false;
    });
  }

  emp: any;

  delete(employee) {
    this.emp = employee;
    this.emp = '';
  }

}
