export interface IEmployee {
  id ? : number;
  name: string;
  position: string;
  salary: string;
  createdAt ? : string;
}
