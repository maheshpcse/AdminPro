import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from "rxjs/operators"; 
import { IEmployee } from '../interfaces/iemployee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  private empUrl = `http://localhost:3000/`;
  private channel: any;

  constructor(private http: HttpClient) { }

  getChannel() {
    return this.channel;
  }

  getEmpList(): Observable<IEmployee[]> {
    return this.http.get(this.empUrl + 'get')
      .pipe(map(res => <IEmployee[]> res));
  }

  addEmpToList(param: IEmployee): Observable<IEmployee> {
    return this.http.post(this.empUrl + "add", param)
      .pipe(map(res => <IEmployee> res));
  }
}
