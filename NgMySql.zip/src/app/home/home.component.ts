import { Component, OnInit } from '@angular/core';
import { AuthService } from '../services/auth.service';
import { FormGroup, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  uploadForm: FormGroup;
  showmsg: boolean;
  data: any;

  constructor(
    private authSrv: AuthService,
    private fb: FormBuilder
  ) { }

  ngOnInit() {
    this.showmsg = false;
    this.uploadForm = this.fb.group({
      file: ['']
    });
    // this.getfiledata();
  }

  onFileSelected(event) {
    console.log(event.target.files[0]);
    if (event.target.files.length > 0) {
      const file = event.target.files[0];
      this.uploadForm.get('file').setValue(file);
    }
  }

  onSubmit() {
    const formData = new FormData();
    formData.append('file', this.uploadForm.get('file').value);
    this.authSrv.addfile(formData).subscribe(
      (res) => {
        console.log("File uploaded successfully", res);
        this.showmsg = true;
        this.data = res['data'];
        this.hidemsg();
      }, (err) => {
        console.log("No file uploaded", err);
      }
    )
  }

  hidemsg() {
    setInterval(() => {
      this.showmsg = false;
    }, 1000);
  }

  excel = [];
  fileData: any = [];

  getfiledata() {
    this.authSrv.readfile().subscribe(
      (res) => {
        console.log("File read success", res);
        this.fileData = res;
        this.fileData.forEach(row => {
          this.excel.push(row);
        });
      }, (err) => {
        console.log("No file read", err);
      });
  }
}
