import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {

  user: Object = {
    username: '',
    email:'',
    phonenumber:''
  }

  users: any;

  constructor() { }

  ngOnInit() {
  }

}
