import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  userData:any = {
    username: '',
    email:'',
    password:'',
    phonenumber:'',
  }

  constructor() { }

  ngOnInit() {
  }

}
