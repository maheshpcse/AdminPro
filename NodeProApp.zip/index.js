require('./model/db.connection');
// require('./model/db.conn');
const express = require('express');
const app = express();
const path = require('path');
var bodyParser = require('body-parser');
var CONFIG = require('./config/index');

// middleware functions
app.use(express.static(path.join(__dirname, 'public')));

app.use(function (req, res, next) {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Credentials', 'true');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, PATCH, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Origin, Authorization, X-Requested-With, Content-Type, x-access-token, Content-Length, Accept');
  next();
});

app.use(bodyParser.urlencoded({
  extended: false
}));

app.use(bodyParser.json());

// var userRoutes = require('./routes/user.routes.js');
// app.use('/api', userRoutes);

app.listen(CONFIG.PORT, function(){
  console.log('Express server is listening on port ' + CONFIG.PORT);
});