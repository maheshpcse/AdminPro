const host = '127.0.0.1';
const port = 3000;
const dbUrl = 'mongodb://rootUser:password1@ds235197.mlab.com:35197/myusers';
const dbUser = 'rootUser';
const dbPwd = 'password1';
const secretkey = 'maheshcse';

module.exports = {
    HOST: host,
    PORT: port,
    DBURL: dbUrl,
    DBUSER: dbUser,
    DBPWD: dbPwd,
    SECRETKEY: secretkey
}