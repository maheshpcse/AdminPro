const mongoose = require('mongoose');
const CONFIG = require('../config/index.js');
require('./users.model');

const options = {
    user: CONFIG.DBUSER,
    pass: CONFIG.DBPWD,
    useNewUrlParser: true
};

mongoose.connect(CONFIG.DBURL, options);
var _conn = mongoose.connection;

_conn.on('error', function(error){
    console.error('Conection failed to DB');
    console.log(error);
});

_conn.once('open', function(){
    console.log('Mongoose connection successfully');
});