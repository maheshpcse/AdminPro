const mongoose = require('mongoose');

var userSchema = mongoose.Schema({
    role: {
        type: String,
        "default": 'user'
    },
    firstname: String,
    lastname: String,
    email: String,
    password: String,
    phonenumber: Number,
    address: String,
    city: String,
    state: String,
    zipcode: Number
});

mongoose.model('User', userSchema, 'users');