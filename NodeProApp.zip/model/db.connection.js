var MongoClient = require('mongodb').MongoClient;
// var url = "mongodb://rootUser:password1@ds157276.mlab.com:57276/mydb";
var mongodbUrl = `mongodb://localhost:27017`;

const options = {
  useNewUrlParser: true
}

// MongoClient.connect(url,options, function(err, db) {
//   if (err) throw err;
//   var dbo = db.db('mydb');
//   dbo.collection("customers").find().limit(3).toArray(function(err, res) {
//     if (err) throw err;
//     console.log(res);
//     db.close();
//   });
// });

MongoClient.connect(mongodbUrl, options, function(err, db) {
  if (err) throw err;
  var dbo = db.db('mydb');
  // dbo.collection('employees').insertMany([
  //   {
  //     name: 'Sai',
  //     age: 26,
  //     status: 'incomplete'
  //   },
  //   {
  //     name: 'Venkat',
  //     age: 27,
  //     status: 'complete'
  //   }
  // ]).then(res=>{
  //   console.log("successfully inserted documents", res);
    dbo.collection('employees').find({}).limit(2).toArray(function(err, res){
      if (err) throw err;
      console.log(res);      
    })
  // }).catch(err=>{
  //   console.log("Error while inserting documents", err);
  // })
})