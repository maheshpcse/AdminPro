var mongoose = require('mongoose');

module.exports.addEmployee = function(req, res, next) {
    var name = req.body.name;
    var email = req.body.email;
    var phonenumber = req.body.phonenumber;

    console.log("Name===>", name);
    console.log("Email===>", email);
    console.log("Phonenumber===>", phonenumber);           
}