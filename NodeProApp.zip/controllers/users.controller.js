const mongoose = require('mongoose');
var User = mongoose.model('User');

//Get All Users
module.exports.getAllusers = function(req, res, next) {
    User
        .find({})
        .exec(function(err, users){
            if(err){
                console.log(err);
                res.status(404).json({
                    messsage: 'Users not found',
                    error: err
                });
            } else {
                console.log('Found users', users.length);
                res.status(200).json(users);
            }
        });
}

//Get One User By Id
module.exports.getOneUserById = function(req, res, next) {
    var userId = req.params.userId;
    console.log(userId);
    if(userId) {
        User
            .findById(userId)
            .exec(function(err, user){
                if(err) {
                    console.log(err);
                    res.status(500).json({
                        messsage: 'Error finding userId',
                        error: err
                    });
                } else {
                    console.log(user);
                    res.status(200).json(user);
                }
            });
    }
}

//Delete One User By Id
module.exports.deleteOneUserById = function(req, res, next) {
    var userId = req.params.userId;
    console.log(userId);
    if(userId) {
        User
            .findByIdAndRemove(userId)
            .exec(function(err, user){
                if(err) {
                    console.log(err);
                    res.status(500).json({
                        messsage: 'Error while deleting user',
                        error: err
                    });
                } else {
                    console.log('UserId deleted, id :', userId);
                    res.status(200).json({
                        messsage: 'User deleted successfully'
                    });                   
                }
            });
    }
}