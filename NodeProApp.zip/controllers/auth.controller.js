const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
var CONFIG = require('../config/index.js');
var User = mongoose.model('User');

//User Registration
module.exports.userRegistration = function(req, res, next){
    if(!req.body || !req.body.role || !req.body.firstname || !req.body.lastname || !req.body.email || !req.body.password || !req.body.phonenumber || !req.body.address || !req.body.city || !req.body.state || !req.body.zipcode){
        res.status(404).json({
            message: 'Failed to register, required fields are missing'
        });
    } else {
        const saltRounds = 10;
        var salt = bcrypt.genSaltSync(saltRounds);
        var hashPassword = bcrypt.hashSync(req.body.password, salt);
        var newUser = new User({
            role: req.body.role,
            firstname: req.body.firstname,
            lastname: req.body.lastname,
            email: req.body.email,
            password: hashPassword,
            phonenumber:req.body.phonenumber,
            address: req.body.address,
            city: req.body.city,
            state: req.body.state,
            zipcode: req.body.zipcode
        });
        newUser.save(function (err, user) {
            if(err) {
                req.status(500).json({
                    payLoad: {
                        error: err,
                        message: 'Failed to register a user'
                    }
                });
            } else {
                var token = jwt.sign({
                    _id: user._id
                }, CONFIG.SECRETKEY, {
                    expiresIn: 43200
                });
                res.status(200).json({
                    payLoad: {
                        message: 'User registration successful',
                        auth: true,
                        token: token,
                        role: user.role,
                        userId: user._id
                    }
                });
            }
        });
    }
};

//User Login
module.exports.userLogin = function (req, res, next) {
    if(!req.body.email || !req.body.password) {
        res.status(400).json({
            payLoad: {
                message: 'Email and Password cannot be empty',
                auth: false
            }
        });
    } else {
        User.findOne({
            email: req.body.email
        }, function (err, user){
            if(err) {
                res.status(500).json({
                    payLoad: {
                        message: 'Internal server error',
                        auth: false
                    }
                });
            } else {
                if(!user) {
                    res.status(404).json({
                        payLoad: {
                            message: 'User not found, get register'
                        }
                    });
                } else {
                    var isPwd = bcrypt.compareSync(req.body.password, user.password);
                    console.log("isPwd: ", isPwd);
                    if(!isPwd) {
                        res.status(500).json({
                            payLoad: {
                                message: 'Incorrect password',
                                auth: false
                            }
                        });
                    } else {
                        var token = jwt.sign({
                            _id: user._id
                        }, CONFIG.SECRETKEY, {
                            expiresIn: 43200
                        });
                        res.status(200).json({
                            payLoad: {
                                message: 'User login successful',
                                auth: true,
                                token: token,
                                role: user.role,
                                userId: user._id
                            }
                        });
                    }
                }
            }
        })
    }
}

//User login with validate token or not
module.exports.validateToken = function (req, res, next) {
    var token = req.headers['x-access-token'];
    if(!token) {
        res.status(404).json({
            payLoad: {
                message: 'Token not found',
                auth: false,
                token: null
            }
        });
    } else {
        jwt.verify(token, CONFIG.SECRETKEY, function(error, doc){
            if(error) {
                res.status(401).json({
                    payLoad: {
                        message: 'Invalid token',
                        auth: false,
                        token: null
                    }
                });
            } else {
                console.log(doc);
                User.findById(doc._id, function(err, user) {
                    if(err) {
                        res.status(500).json({
                            payLoad: {
                                message: 'Internal server error',
                                auth: false,
                                token: null
                            }
                        });
                    } else if(!user) {
                        res.status(404).json({
                            payLoad: {
                                message: 'User is not validated',
                                auth: false,
                                token: null
                            }
                        });
                    } else {
                        next();
                    }
                });
            }
        });
    }
}