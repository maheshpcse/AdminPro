var express = require('express');
var router = express.Router();
const authCtrl = require('../controllers/auth.controller.js');
const userCtrl = require('../controllers/users.controller.js');
const emplyCtrl = require('../controllers/employee.controller.js');

router.route('/addemployee').post(emplyCtrl.addEmployee)

router
.route('/register')
.post(authCtrl.userRegistration)

router
.route('/login')
.post(authCtrl.userLogin)

router
.route('/token')
.post(authCtrl.validateToken)

router
.route('/users')
.get(userCtrl.getAllusers)

router
.route('/users/:userId')
.get(userCtrl.getOneUserById)

router
.route('/users/:userId')
.delete(userCtrl.deleteOneUserById)


module.exports = router;